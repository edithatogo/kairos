# API Design Review and Compatibility Governance

Every public API addition must complete this review before reaching a stable host-language package.

## API review template

```markdown
# API Review: <name>

## Problem

## Proposed API

### Rust
### C ABI
### Python
### R
### Julia
### TypeScript
### C#
### Go

## Compatibility impact

- Rust API:
- C ABI:
- Arrow schema:
- Host-language APIs:

## Memory ownership

## Error model

## Thread-safety model

## Determinism/replay impact

## Conformance fixtures added

## Alternatives rejected

## Migration/deprecation notes
```

## Compatibility surfaces

KairoECS has four separately versioned compatibility surfaces:

1. Rust crate APIs.
2. C ABI and native library symbols.
3. Host-language package APIs.
4. Arrow telemetry schemas and scenario manifests.

## Public stability levels

| Label | Meaning |
|---|---|
| experimental | May break without migration support. |
| preview | Intended shape is visible; breaking changes require release notes. |
| stable | Breaking changes require semver-major, migration notes, and deprecation window where feasible. |

## Binding consistency rules

- Same concept, same name where idiomatic.
- Same error semantics.
- Same ownership semantics.
- Same determinism semantics.
- Same conformance fixtures.
- Host-language convenience APIs may exist, but must lower to the same contract.
