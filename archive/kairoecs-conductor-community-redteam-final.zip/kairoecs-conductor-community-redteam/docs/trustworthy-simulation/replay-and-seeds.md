# Replay and Seed Manifests

Deterministic replay is central to KairoECS.

```yaml
schema_version: kairoecs.seed.v1
base_seed: 12345
streams:
  arrival_process: 1001
  service_process: 1002
  agent_42: 42042
```

```bash
kairoecs run scenario.yaml --seed-manifest seeds.yaml --replay-trace trace.arrow
```
