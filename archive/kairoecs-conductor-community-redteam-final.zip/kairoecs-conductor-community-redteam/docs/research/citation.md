# Citation

See `CITATION.cff`, `codemeta.json`, `.zenodo.json`, and `paper/`.
