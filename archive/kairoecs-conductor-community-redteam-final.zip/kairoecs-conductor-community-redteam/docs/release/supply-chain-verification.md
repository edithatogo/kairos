# Verifying Release Artifacts

KairoECS releases should provide checksums, SBOMs, artifact attestations/provenance, package registry links, and a source archive.

```mermaid
flowchart TD
    Release[GitHub Release]
    Artifact[Download artifact]
    Checksum[Verify checksum]
    Attestation[Verify attestation]
    SBOM[Review SBOM]
    Install[Install package]

    Release --> Artifact
    Artifact --> Checksum
    Artifact --> Attestation
    Artifact --> SBOM
    Checksum --> Install
    Attestation --> Install
```
