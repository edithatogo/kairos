# KairoECS Release Checklist

## Preflight

- [ ] Naming/package availability confirmed.
- [ ] Version chosen and release branch created.
- [ ] Changelog updated.
- [ ] Compatibility notes updated.
- [ ] Migration guide written if needed.

## Quality

- [ ] Rust core CI green.
- [ ] Python 3.10-3.14 green.
- [ ] R green.
- [ ] Julia green.
- [ ] TypeScript/Wasm green.
- [ ] C# .NET 10-11 green or .NET 11 marked experimental with rationale.
- [ ] Go green.
- [ ] Conformance suite green.
- [ ] Benchmarks reviewed.
- [ ] Security scans reviewed.

## Docs

- [ ] GitHub Pages build green.
- [ ] API docs generated.
- [ ] Quickstarts for all languages updated.
- [ ] Release notes published.

## Artifacts

- [ ] Native libraries built.
- [ ] C headers included.
- [ ] Checksums generated.
- [ ] SBOM generated.
- [ ] GitHub Release draft reviewed.
- [ ] Registry dry-runs complete.

## Publish

- [ ] crates.io.
- [ ] PyPI.
- [ ] npm.
- [ ] NuGet.
- [ ] R-universe/CRAN as appropriate.
- [ ] Julia registry/artifacts.
- [ ] Go tag.
- [ ] GitHub Pages.
