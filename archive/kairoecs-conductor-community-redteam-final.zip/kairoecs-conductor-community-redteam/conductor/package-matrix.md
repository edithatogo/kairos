# KairoECS Package and Registry Matrix

## Naming policy

The public project name is **KairoECS**. Public package names should use the distinctive `kairo-ecs` / `Kairo.ECS` / `KairoECS.jl` family rather than a bare `kairo` or `kairos` name.

Before the first public release, re-check every registry manually and reserve names where appropriate. Treat name availability as a release blocker, not an assumption.

## Preferred package names

| Ecosystem | Preferred name | Notes / fallbacks |
|---|---|---|
| Rust root crate | `kairo-ecs` | Thin meta crate that re-exports stable user-facing Rust APIs. |
| Rust internal crates | `kairo-ecs-core`, `kairo-ecs-state`, `kairo-ecs-ffi`, `kairo-ecs-arrow`, `kairo-ecs-viz`, `kairo-ecs-experiment`, `kairo-ecs-conformance` | Avoid bare `kairo-*` unless due diligence passes. |
| Python distribution | `kairo-ecs` | Import as `kairo_ecs`. |
| Python import | `kairo_ecs` | Never require `import kairo` or `import kairoecs`. |
| R package | `kairoECS` | Use camel-case R package name if accepted by the release channel. |
| Julia package | `KairoECS.jl` | Module name `KairoECS`. |
| TypeScript / npm | `@kairo-ecs/core` | Use scoped packages for future `@kairo-ecs/arrow`, `@kairo-ecs/viz`, etc. |
| C# / NuGet | `Kairo.ECS` | Future packages may use `Kairo.ECS.Native`, `Kairo.ECS.Arrow`, etc. |
| Go module | `github.com/<org>/kairo-ecs` | Go package name may be `kairo` or `kairoecs`; prefer simple local package names with explicit module path. |
| C ABI library | `libkairo_ecs` | Header: `kairo_ecs.h`; function prefix: `kairo_ecs_`. |
| CLI | `kairoecs` | CLI can be a compact command while packages remain explicit. |
| Docs domain | `kairo-ecs.dev` or `kairo-ecs.org` | Verify availability and trademark risk. |

## Publishing stages

| Stage | Goal | Registries |
|---|---|---|
| 0.1 alpha | Rust core + C ABI preview | crates.io optional, GitHub Releases |
| 0.2 alpha | Python + Arrow telemetry preview | TestPyPI/PyPI, GitHub Releases |
| 0.3 alpha | TypeScript/Wasm + docs site | npm, GitHub Pages |
| 0.4 beta | R/Julia/C#/Go previews | R-universe, Julia dev registry, NuGet pre-release, Go tags |
| 0.5 beta | Full conformance suite required | all test registries |
| 1.0 | Stable ABI/schema/API baseline | production registries |

## Package artifact checklist

Every package must include:

```text
README
LICENSE
version
changelog link
API docs link
examples
native library loading strategy
platform support table
minimum runtime version
conformance test status
security reporting link
```

## Platform artifacts

| Platform | Native artifacts |
|---|---|
| Linux x86_64 | `.so`, wheels, npm wasm/node artifacts, NuGet runtime asset |
| Linux aarch64 | `.so`, wheels where supported, NuGet runtime asset |
| macOS x86_64 | `.dylib`, wheels, NuGet runtime asset |
| macOS arm64 | `.dylib`, wheels, NuGet runtime asset |
| Windows x86_64 | `.dll`, wheels, NuGet runtime asset |
| Wasm | `.wasm`, `.js`, `.d.ts` |

## Registry-specific notes

### Python

Target Python 3.10-3.14. Prefer `abi3-py310` if feasible. Otherwise build per Python version.

### C#

Target `net10.0` and `net11.0`. Keep the .NET 11 lane experimental until runner/toolchain availability is verified.

### R

Start with R-universe or GitHub releases. CRAN should wait until native artifact strategy and reverse dependency checks are mature.

### Julia

Start with GitHub + Artifacts. Move to General Registry and JLL packaging after ABI stability.

### Go

Release using semantic Git tags. Keep cgo instructions explicit.

## Detailed dependency/tooling inventory

See `conductor/package-ecosystem-plan.md` for crate-level, binding-level, documentation, security, and release tooling plans.

Important assumptions to verify before public release:

- Python support targets 3.10, 3.11, 3.12, 3.13, and 3.14.
- C# support targets .NET 10 as stable and .NET 11 as preview/allowed-failure until GA.
- Registry release workflows should prefer OIDC/provenance when supported and use scoped tokens only where no better mechanism exists.
