# Versioning and Compatibility Contract

## Surfaces

KairoECS versions these surfaces separately:

```text
Product/package version
Rust API version
C ABI version
Arrow schema versions
Conformance suite version
```

## Breaking changes

Breaking changes include:

```text
changing event ordering semantics
changing SimTime representation without adapter
changing FFI function signatures
removing or changing Arrow fields
changing deterministic fixture outputs without version bump
changing host-language API behavior without migration guide
```

## Compatibility files

Each release must update:

```text
CHANGELOG.md
docs/release/compatibility.md
docs/release/migration.md if needed
conductor/contracts/versioning-compatibility.md if policy changes
```
