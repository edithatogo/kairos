# KairoECS Governance, Maintenance, and Community

## Governance files

The repo should include:

```text
LICENSE
CODE_OF_CONDUCT.md
CONTRIBUTING.md
SECURITY.md
MAINTAINERS.md
GOVERNANCE.md
CITATION.cff
CHANGELOG.md
.github/CODEOWNERS
.github/PULL_REQUEST_TEMPLATE.md
.github/ISSUE_TEMPLATE/
docs/adr/
```

## Licensing recommendation

Start with dual license:

```text
MIT OR Apache-2.0
```

This is common in Rust ecosystems and friendly to commercial and open-source adoption. Confirm compatibility with all dependencies before release.

## Naming/legal due diligence

Because “KairoECS” appears in existing ecosystem references, Track 00 must include:

```text
crates.io name check
PyPI name check
npm name check
NuGet name check
R package name check
Julia package name check
Go module/org check
GitHub org/repo check
trademark search
OpenCollective/project-name review
fallback package naming decision
```

## Maintainer model

Roles:

```text
Core maintainers
Binding maintainers
Docs maintainers
Release managers
Security responders
Triage maintainers
```

## Issue triage

Labels:

```text
area:core
area:ecs
area:ffi
area:arrow
area:viz
area:python
area:r
area:julia
area:typescript
area:csharp
area:go
area:docs
area:ci
area:release
type:bug
type:feature
type:perf
type:security
type:question
priority:critical
priority:high
priority:normal
status:blocked
status:needs-design
status:good-first-issue
```

## Decision records

Use ADRs for:

```text
public API decisions
FFI ABI changes
Arrow schema changes
scheduler algorithm changes
unsafe code approval
dependency additions to core crates
licensing/naming changes
```

## Maintenance automation

```text
Dependabot or Renovate
CodeQL
cargo audit
cargo deny
release-drafter or release-plz
stale issue policy only after project maturity
scheduled conformance/benchmark jobs
scheduled docs link checks
scheduled registry dry-runs
```

## Deprecation policy

Any public feature deprecation needs:

```text
deprecation notice in docs
compiler/runtime warning where possible
migration guide
minimum one minor release grace period before removal pre-1.0 where feasible
major version for breaking removals after 1.0
```
