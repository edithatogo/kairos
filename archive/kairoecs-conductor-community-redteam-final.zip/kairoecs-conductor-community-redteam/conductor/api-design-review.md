# API Design Review Template

## Feature

## User story

## Rust API

## C ABI shape

## Python 3.10-3.14 API

## R API

## Julia API

## TypeScript/Wasm API

## C# .NET 10-11 API

## Go API

## Batch behavior

## Error behavior

## Memory ownership

## Determinism impact

## Arrow schema impact

## Conformance fixture impact

## Backwards compatibility

## Red-team objections

## Decision

- [ ] accepted
- [ ] rejected
- [ ] needs prototype
- [ ] needs ADR
