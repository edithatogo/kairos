# 03 The Flow: DES Trajectory API & ABM Behavior API — spec.md

## Mission

Create equal first-class modeling surfaces: DES trajectory/process API and ABM behavior/decision API over the same ECS/event kernel.

## Primary subagent

```text
des-api-agent + abm-api-agent
```

## Dependencies

```text
Track 01 contracts; implementation depends on scheduler/ECS ports.
```

## Owned paths

```text
crates/kairo-ecs-des, crates/kairo-ecs-abm, examples/flow/
```

## Parallel-safe with

Most tracks are parallel-safe after their contract inputs are accepted. See `conductor/parallel-execution.md` for the wave model.

## Inputs

- Accepted project identity and naming status where relevant.
- Relevant files under `conductor/contracts/`.
- Prior track handoff notes.

## Outputs

- Implementation or scaffolding in owned paths.
- Tests or test-plan.
- Docs updates.
- Release notes or compatibility notes when public surfaces change.




## Acceptance criteria

- Owned paths are created and documented.
- Contract inputs and outputs are explicit.
- Track tests or scaffold checks exist.
- CI gate is defined.
- Documentation impact is recorded.
- Release implications are recorded.
- `handoff.md` is completed before merge.


## Quality gates

Use the gates in `conductor/quality-gates.md`. Track-specific gates must be listed in `test-matrix.md`.
