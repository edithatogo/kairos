# Handoff — 03 The Flow: DES Trajectory API & ABM Behavior API

## Summary

TBD by subagent.

## Files changed

TBD.

## Contracts consumed

TBD.

## Contracts changed

TBD.

## Tests added

TBD.

## Known risks

TBD.

## Integration notes

TBD.
