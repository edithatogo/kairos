# Handoff — 02 The Bridge: kairo-ecs-ffi, UniFFI & Diplomat

## Summary

TBD by subagent.

## Files changed

TBD.

## Contracts consumed

TBD.

## Contracts changed

TBD.

## Tests added

TBD.

## Known risks

TBD.

## Integration notes

TBD.
