# Track 19 Plan: Research Software, Citation & Archival

## Phase 0 — Contract alignment

### Task 0.1 — Read existing contracts
- Review core, FFI, Arrow, conformance, versioning, and release contracts.
- Identify where this track consumes or amends those contracts.
- Open an ADR if public API, ABI, schema, or governance commitments change.

### Task 0.2 — Define owned artifacts
- List files owned by this track.
- Add owner/subagent to `conductor/subagents.md` if missing.
- Add CI/release gates if the artifact can be machine-checked.

## Phase 1 — Minimum viable public artifact

### Task 1.1 — Create the first usable version
- Produce the minimal doc, manifest, workflow, template, benchmark, example, or checklist needed for community use.
- Include one realistic KairoECS example rather than placeholder text.

### Task 1.2 — Add review criteria
- Add red-team prompts.
- Add devil's advocate objections.
- Add measurable acceptance criteria.

## Phase 2 — Automation and validation

### Task 2.1 — Wire into CI where possible
- Add linting, schema validation, doctests, fixture checks, or workflow smoke tests.
- Use path guards for not-yet-created packages.

### Task 2.2 — Connect to release gates
- Define what blocks alpha, beta, release candidate, and stable release.
- Add required artifacts to `conductor/delivery-readiness-checklist.md`.

## Phase 3 — Cross-track integration

### Task 3.1 — Handoff to dependent tracks
- Document exactly what other subagents can rely on.
- Provide examples and fixtures rather than prose-only handoffs.

### Task 3.2 — Add community-facing documentation
- Ensure the docs site has a page explaining the output.
- Link from the model zoo, API reference, release page, or contributor guide as appropriate.

## Phase 4 — Closeout

### Task 4.1 — Run quality gates
- Check markdown links.
- Validate Mermaid diagrams.
- Run relevant test or dry-run workflows.

### Task 4.2 — Update risk register
- Move resolved risks to mitigated.
- Promote unresolved high risks to release blockers.
