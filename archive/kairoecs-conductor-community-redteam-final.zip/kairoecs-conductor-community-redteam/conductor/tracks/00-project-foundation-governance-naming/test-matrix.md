# Test Matrix — 00 Project Foundation, Governance & Naming

## Required tests

- Unit tests or scaffold tests.
- Integration tests if this track touches public behavior.
- Conformance fixture tests if this track touches cross-language behavior.
- Docs build if this track changes docs.
- Package dry-run if this track changes package metadata.

## CI command placeholder

```bash
# Replace with track-specific commands as implementation lands.
echo "Run 00 Project Foundation, Governance & Naming tests"
```
