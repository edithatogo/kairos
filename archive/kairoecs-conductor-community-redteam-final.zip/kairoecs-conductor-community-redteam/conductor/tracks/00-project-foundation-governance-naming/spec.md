# 00 Project Foundation, Governance & Naming — spec.md

## Mission

Initialize the KairoECS repository, governance model, licensing, naming due diligence, community standards, issue templates, and project automation skeleton.

## Primary subagent

```text
foundation-agent
```

## Dependencies

```text
None. Starts immediately.
```

## Owned paths

```text
root metadata, .github templates, governance docs, naming checklist
```

## Parallel-safe with

Most tracks are parallel-safe after their contract inputs are accepted. See `conductor/parallel-execution.md` for the wave model.

## Inputs

- Accepted project identity and naming status where relevant.
- Relevant files under `conductor/contracts/`.
- Prior track handoff notes.

## Outputs

- Implementation or scaffolding in owned paths.
- Tests or test-plan.
- Docs updates.
- Release notes or compatibility notes when public surfaces change.




## Acceptance criteria

- Owned paths are created and documented.
- Contract inputs and outputs are explicit.
- Track tests or scaffold checks exist.
- CI gate is defined.
- Documentation impact is recorded.
- Release implications are recorded.
- `handoff.md` is completed before merge.


## Quality gates

Use the gates in `conductor/quality-gates.md`. Track-specific gates must be listed in `test-matrix.md`.
