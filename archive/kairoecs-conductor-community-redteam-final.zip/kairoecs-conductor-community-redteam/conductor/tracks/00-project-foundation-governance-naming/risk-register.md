# Risk Register — 00 Project Foundation, Governance & Naming

| Risk | Impact | Mitigation |
|---|---|---|
| Contract drift | Subagents diverge | Use `conductor/contracts` and conformance fixtures |
| CI blind spot | Regressions merge | Add track-specific workflow/test gate |
| Public API churn | Binding maintenance cost | Gate public surface changes through ADR |
| Package/version mismatch | Release failure | Use publishing dry-runs before production |
