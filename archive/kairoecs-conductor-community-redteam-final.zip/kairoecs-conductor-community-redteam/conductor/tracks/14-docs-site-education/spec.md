# 14 Documentation Site & Education — spec.md

## Mission

Create Docusaurus GitHub Pages site, concept docs, tutorials, API doc aggregation, and examples.

## Primary subagent

```text
docs-agent
```

## Dependencies

```text
Track 00. Starts immediately from specs.
```

## Owned paths

```text
docs, website, examples/docs
```

## Parallel-safe with

Most tracks are parallel-safe after their contract inputs are accepted. See `conductor/parallel-execution.md` for the wave model.

## Inputs

- Accepted project identity and naming status where relevant.
- Relevant files under `conductor/contracts/`.
- Prior track handoff notes.

## Outputs

- Implementation or scaffolding in owned paths.
- Tests or test-plan.
- Docs updates.
- Release notes or compatibility notes when public surfaces change.


## Docs scope

Docs must include:

```text
conceptual intro to KairoECS
DES tutorial: factory bottleneck
ABM tutorial: flocking behavior
hybrid tutorial: agents entering queues/resources
API quickstarts for every language
FFI and Arrow schema reference
performance guide
release and compatibility guide
governance/contribution guide
```



## Acceptance criteria

- Owned paths are created and documented.
- Contract inputs and outputs are explicit.
- Track tests or scaffold checks exist.
- CI gate is defined.
- Documentation impact is recorded.
- Release implications are recorded.
- `handoff.md` is completed before merge.


## Quality gates

Use the gates in `conductor/quality-gates.md`. Track-specific gates must be listed in `test-matrix.md`.
