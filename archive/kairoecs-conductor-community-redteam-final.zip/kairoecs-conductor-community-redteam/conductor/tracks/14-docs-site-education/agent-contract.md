# Agent Contract — 14 Documentation Site & Education

## Owner

docs-agent

## Owned paths

```text
docs, website, examples/docs
```

## Handoff rules

- Do not change public contracts without ADR.
- Do not modify other track paths without noting the dependency in `handoff.md`.
- Add tests before requesting integration.
- Update docs for user-visible behavior.
