# 12 Conformance, Testing & Benchmarks — spec.md

## Mission

Create the shared correctness, performance, fuzz, and cross-language fixture suite that every binding must satisfy.

## Primary subagent

```text
conformance-agent + performance-agent
```

## Dependencies

```text
Track 00 starts design; Track 01/02/04 implementation expands fixtures.
```

## Owned paths

```text
conformance, tests/conformance, benches, crates/kairo-ecs-bench
```

## Parallel-safe with

Most tracks are parallel-safe after their contract inputs are accepted. See `conductor/parallel-execution.md` for the wave model.

## Inputs

- Accepted project identity and naming status where relevant.
- Relevant files under `conductor/contracts/`.
- Prior track handoff notes.

## Outputs

- Implementation or scaffolding in owned paths.
- Tests or test-plan.
- Docs updates.
- Release notes or compatibility notes when public surfaces change.




## Acceptance criteria

- Owned paths are created and documented.
- Contract inputs and outputs are explicit.
- Track tests or scaffold checks exist.
- CI gate is defined.
- Documentation impact is recorded.
- Release implications are recorded.
- `handoff.md` is completed before merge.


## Quality gates

Use the gates in `conductor/quality-gates.md`. Track-specific gates must be listed in `test-matrix.md`.
