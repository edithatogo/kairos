# 04 The Analyst: kairo-ecs-arrow Telemetry — spec.md

## Mission

Implement Arrow schemas, telemetry collection modes, IPC export, and cross-language analytics handoffs.

## Primary subagent

```text
arrow-agent
```

## Dependencies

```text
Track 01 type contract; can design schema in parallel.
```

## Owned paths

```text
crates/kairo-ecs-arrow, schemas/arrow, examples/telemetry/
```

## Parallel-safe with

Most tracks are parallel-safe after their contract inputs are accepted. See `conductor/parallel-execution.md` for the wave model.

## Inputs

- Accepted project identity and naming status where relevant.
- Relevant files under `conductor/contracts/`.
- Prior track handoff notes.

## Outputs

- Implementation or scaffolding in owned paths.
- Tests or test-plan.
- Docs updates.
- Release notes or compatibility notes when public surfaces change.




## Acceptance criteria

- Owned paths are created and documented.
- Contract inputs and outputs are explicit.
- Track tests or scaffold checks exist.
- CI gate is defined.
- Documentation impact is recorded.
- Release implications are recorded.
- `handoff.md` is completed before merge.


## Quality gates

Use the gates in `conductor/quality-gates.md`. Track-specific gates must be listed in `test-matrix.md`.
