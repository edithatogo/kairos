# 06 Python Binding 3.10-3.14 — spec.md

## Mission

Provide idiomatic Python package with wheels, pyarrow integration, conformance tests, and Python 3.10-3.14 support.

## Primary subagent

```text
python-agent
```

## Dependencies

```text
Track 02 FFI RC and Track 04 Arrow schema RC.
```

## Owned paths

```text
bindings/python, packaging/python
```

## Parallel-safe with

Most tracks are parallel-safe after their contract inputs are accepted. See `conductor/parallel-execution.md` for the wave model.

## Inputs

- Accepted project identity and naming status where relevant.
- Relevant files under `conductor/contracts/`.
- Prior track handoff notes.

## Outputs

- Implementation or scaffolding in owned paths.
- Tests or test-plan.
- Docs updates.
- Release notes or compatibility notes when public surfaces change.


## Python version matrix

Required support:

```text
Python 3.10
Python 3.11
Python 3.12
Python 3.13
Python 3.14
```

Preferred wheel strategy:

```text
PyO3 abi3-py310 if feasible, otherwise per-version wheels.
```

Quality gates:

```bash
pytest
ruff check
python -m build
maturin build or cibuildwheel
python -c "import kairo_ecs; kairo_ecs.self_check()"
```



## Acceptance criteria

- Owned paths are created and documented.
- Contract inputs and outputs are explicit.
- Track tests or scaffold checks exist.
- CI gate is defined.
- Documentation impact is recorded.
- Release implications are recorded.
- `handoff.md` is completed before merge.


## Quality gates

Use the gates in `conductor/quality-gates.md`. Track-specific gates must be listed in `test-matrix.md`.
