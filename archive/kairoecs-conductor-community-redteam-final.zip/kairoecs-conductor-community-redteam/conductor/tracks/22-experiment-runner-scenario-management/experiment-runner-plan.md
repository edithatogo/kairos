# Experiment Runner Plan

## Proposed crate/package

`kairo-ecs-experiment`

## Purpose

Run replications, parameter sweeps, and scenario batches reproducibly across local machines, CI, and HPC/cloud environments.

## Scenario manifest sketch

```toml
[model]
name = "factory_bottleneck"
version = "0.1.0"
entrypoint = "examples/des/factory_bottleneck"

[simulation]
until = "8h"
replications = 100
base_seed = 12345

[parameters]
arrival_rate = [0.8, 1.0, 1.2]
service_rate = [1.0, 1.1]

[output]
format = "arrow"
path = "runs/factory_bottleneck"
```

## Experiment data flow

```mermaid
flowchart LR
    Manifest[Scenario manifest] --> Matrix[Parameter matrix]
    Matrix --> Seeds[Seed policy]
    Seeds --> Runner[Parallel runner]
    Runner --> Outputs[Arrow/Parquet outputs]
    Runner --> Logs[Structured logs]
    Outputs --> Compare[Scenario comparison]
    Compare --> Report[HTML/Markdown report]
```
