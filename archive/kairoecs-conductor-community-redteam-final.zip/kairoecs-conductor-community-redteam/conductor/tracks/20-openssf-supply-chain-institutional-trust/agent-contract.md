# Agent Contract: security-agent

## Track

Track 20: OpenSSF, Supply Chain Trust & Institutional Readiness

## Owned paths

- `conductor/tracks/20-openssf-supply-chain-institutional-trust/`
- Track-specific docs/examples/templates named in `plan.md`

## Required handoff

- Summary of artifacts produced.
- Release gates added or changed.
- Contracts consumed.
- Risks discovered.
- Follow-up issues for other subagents.

## Prohibited changes without ADR

- Public Rust APIs.
- C ABI signatures.
- Arrow schema field semantics.
- Package names or registry publication policy.
- Compatibility promises.
