# Track 20: OpenSSF, Supply Chain Trust & Institutional Readiness

## Purpose

Move from basic CI to verifiable supply-chain trust, Scorecard, signed artifacts, SBOMs, and vulnerability response.

## Why this track exists

KairoECS is not only a Rust kernel. It is a multi-language research and engineering ecosystem. This track protects the project from the most common failure mode for ambitious open-source infrastructure: impressive internals with insufficient trust, examples, packaging, governance, and contributor experience.

## Primary subagent

`security-agent`

## Parallelization model

This track is designed to run in parallel with core implementation. The subagent owns docs, policies, examples, checklists, manifests, fixtures, and automation scaffolds. It must not block kernel development unless it identifies a release-blocking risk.

## Inputs

- `conductor/contracts/core-contract.md`
- `conductor/contracts/ffi-contract.md`
- `conductor/contracts/arrow-schema-contract.md`
- `conductor/contracts/conformance-contract.md`
- `conductor/package-ecosystem-plan.md`
- `reviews/red-team-report.md`

## Outputs

- Track-specific docs, templates, fixtures, examples, or workflow gates.
- Updated risk register where applicable.
- Handoff notes for adjacent subagents.
- Release-readiness criteria that can be checked automatically where possible.

## Acceptance criteria

- The track has a clear public-facing output, not just internal notes.
- The output is testable, reviewable, or linked to a release gate.
- It includes failure modes and countermeasures.
- It does not duplicate core implementation work owned by Tracks 01-05.
- It supports at least one of: adoption, trust, reproducibility, maintainability, or compatibility.

## Non-goals

- Replacing the core scheduler or ECS design.
- Publishing packages before naming, legal, security, and compatibility gates pass.
- Adding domain-specific complexity to `kairo-ecs-core`.
