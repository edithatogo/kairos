# Community Adoption Plan

## Adoption thesis

KairoECS will be adopted only if users can solve recognizable simulation problems within minutes and contributors can find useful work within hours.

## Public surfaces

- Landing page with clear positioning: "open-source, Rust-powered hybrid DES/ABM with polyglot bindings".
- `examples/` gallery with runnable DES, ABM, hybrid, and data-science examples.
- Tutorials for first models in Rust and Python before all bindings are mature.
- Discussions categories: ideas, help, show-and-tell, benchmarks, model zoo, governance.
- Triage labels: `good first issue`, `help wanted`, `track:core`, `track:ffi`, `track:binding-python`, `needs-repro`, `needs-design-review`.

## Community ladder

1. User
2. Contributor
3. Area reviewer
4. Maintainer
5. Release manager
6. Steering member

Promotion requires demonstrated review quality, care for users, and reliability; not just code volume.

## Adoption funnel

```mermaid
flowchart LR
    Discover[Discover KairoECS] --> Install[Install package]
    Install --> RunExample[Run example]
    RunExample --> Modify[Modify model]
    Modify --> Analyze[Analyze Arrow output]
    Analyze --> Share[Share reproducible result]
    Share --> Contribute[Contribute issue/model/PR]
```
