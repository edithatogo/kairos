# Test Matrix: Track 27 Developer Experience & Reproducible Environments

| Check | Required by alpha | Required by beta | Required by 1.0 |
|---|---:|---:|---:|
| Markdown lint/link check | yes | yes | yes |
| Mermaid render check | yes | yes | yes |
| Artifact existence check | yes | yes | yes |
| Contract compatibility check | no | yes | yes |
| Release gate integration | no | yes | yes |
| Cross-language conformance relevance reviewed | no | yes | yes |
| Red-team objections answered | yes | yes | yes |
