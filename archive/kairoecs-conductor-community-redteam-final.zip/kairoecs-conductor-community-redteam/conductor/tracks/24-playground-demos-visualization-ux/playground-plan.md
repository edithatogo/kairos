# Playground, Demos & Visualization UX Plan

## Goal

Make KairoECS understandable through interactive examples before users install a toolchain.

## Components

- Wasm demo runner
- event timeline inspector
- queue/resource visualizer
- agent map visualizer
- Arrow telemetry table/chart viewer
- model zoo browser

## UX flow

```mermaid
journey
    title KairoECS first-user journey
    section Discover
      Reads landing page: 4: User
      Opens playground: 5: User
    section Try
      Runs factory bottleneck demo: 5: User
      Changes arrival rate: 5: User
      Watches queue length change: 5: User
    section Adopt
      Downloads Python notebook: 4: User
      Runs local simulation: 4: User
      Exports Arrow results: 5: User
```
