# 01 The Heart: kairo-ecs-core & kairo-ecs-state — plan.md

## Phase 0 — Track startup

- Read `conductor/workflow.md`.
- Read relevant contracts under `conductor/contracts/`.
- Confirm owned paths: `crates/kairo-ecs-types, crates/kairo-ecs-core, crates/kairo-ecs-state, crates/kairo-ecs-rng`.
- Create `agent-contract.md`, `risk-register.md`, `test-matrix.md`, and `handoff.md`.

## Phase 1 — Contract alignment

- Identify all public types, functions, schemas, commands, or package metadata this track consumes.
- Propose contract changes through ADR if required.
- Add fixture stubs for conformance where relevant.

## Phase 2 — Scaffold

- Create package/crate/module skeleton.
- Add minimal tests that prove the scaffold is wired into CI.
- Add placeholder docs with TODO markers tied to Linear/Conductor tasks.

## Phase 3 — Implementation

- Implement the smallest useful vertical slice.
- Add unit tests and integration tests.
- Add conformance fixture tests where relevant.
- Add benchmarks where performance-sensitive.

## Phase 4 — Cross-track integration

- Run owned tests.
- Run affected shared conformance tests.
- Update docs and release notes.
- Ensure no other subagent-owned paths were modified without handoff.

## Phase 5 — Closeout

- Complete `handoff.md`.
- Record risks and follow-up tasks.
- Confirm CI gates.
- Mark track ready for integration.


## Detailed phases

### Phase 1 — Contracts

- Define `SimTime`, `SimDuration`, IDs, errors, event kind.
- Write deterministic ordering fixture.
- Write ADR for time representation.
- Write ADR for handle generation strategy.

### Phase 2 — Priority queue

- Implement stable heap ordering.
- Add insertion sequence.
- Add cancellation marker or generational event table.
- Property-test ordering and cancellation.

### Phase 3 — Run loop

- Implement `step`, `run_for`, `run_until`, `run_until_or_for`.
- Add zero-delay guardrail.
- Add tracing spans.
- Add stats collection.

### Phase 4 — ECS storage

- Implement entity allocator.
- Implement component insertion/removal.
- Implement query API needed by DES/ABM.
- Benchmark 1M entities.

### Phase 5 — RNG

- Implement run seed.
- Implement entity stream derivation.
- Add reproducibility fixture.

### Phase 6 — FFI readiness

- Create a pure Rust facade that maps cleanly to handles/status codes.
- Freeze minimal API for Track 02.
- Add docs for binding agents.
