# 15 Packaging, Publishing & Delivery — spec.md

## Mission

Create registry workflows, package manifests, native artifact assembly, dry runs, and GitHub Release output.

## Primary subagent

```text
release-agent + binding agents
```

## Dependencies

```text
Binding scaffolds; can create templates early.
```

## Owned paths

```text
packaging, .github/workflows/release.yml
```

## Parallel-safe with

Most tracks are parallel-safe after their contract inputs are accepted. See `conductor/parallel-execution.md` for the wave model.

## Inputs

- Accepted project identity and naming status where relevant.
- Relevant files under `conductor/contracts/`.
- Prior track handoff notes.

## Outputs

- Implementation or scaffolding in owned paths.
- Tests or test-plan.
- Docs updates.
- Release notes or compatibility notes when public surfaces change.


## Publishing scope

Publishing must include dry-runs before production:

```text
crates.io dry-run
TestPyPI then PyPI
npm dry-run/access check
NuGet pack/validation
R-universe/GitHub package build; CRAN later
Julia artifacts/dev registry; General Registry later
Go semantic tag
GitHub Release native artifacts
GitHub Pages docs deploy
```



## Acceptance criteria

- Owned paths are created and documented.
- Contract inputs and outputs are explicit.
- Track tests or scaffold checks exist.
- CI gate is defined.
- Documentation impact is recorded.
- Release implications are recorded.
- `handoff.md` is completed before merge.


## Quality gates

Use the gates in `conductor/quality-gates.md`. Track-specific gates must be listed in `test-matrix.md`.
