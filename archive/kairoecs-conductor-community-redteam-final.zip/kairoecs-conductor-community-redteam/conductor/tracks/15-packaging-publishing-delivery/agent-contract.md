# Agent Contract — 15 Packaging, Publishing & Delivery

## Owner

release-agent + binding agents

## Owned paths

```text
packaging, .github/workflows/release.yml
```

## Handoff rules

- Do not change public contracts without ADR.
- Do not modify other track paths without noting the dependency in `handoff.md`.
- Add tests before requesting integration.
- Update docs for user-visible behavior.
