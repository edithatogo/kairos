# Agent Contract: api-governance-agent

## Track

Track 25: API Design Review & Compatibility Governance

## Owned paths

- `conductor/tracks/25-api-design-review-compatibility-governance/`
- Track-specific docs/examples/templates named in `plan.md`

## Required handoff

- Summary of artifacts produced.
- Release gates added or changed.
- Contracts consumed.
- Risks discovered.
- Follow-up issues for other subagents.

## Prohibited changes without ADR

- Public Rust APIs.
- C ABI signatures.
- Arrow schema field semantics.
- Package names or registry publication policy.
- Compatibility promises.
