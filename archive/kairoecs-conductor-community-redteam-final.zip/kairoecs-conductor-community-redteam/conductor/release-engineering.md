# KairoECS Release Engineering

## Release model

KairoECS has four compatibility surfaces:

```text
1. Rust crate API
2. C ABI
3. Host-language APIs
4. Arrow telemetry schemas
```

A release is only stable if all four surfaces have documented compatibility expectations.

## Versioning

Use SemVer at the product level, with explicit schema/ABI versions:

```text
KairoECS package version: 0.4.0
C ABI version: kairo_ecs_ffi_abi_v1
Arrow event schema: kairo_ecs.event_log.v1
Conformance suite: kairoecs.conformance.v1
```

## Release train

```mermaid
flowchart LR
    Dev[main branch]
    RC[release/x.y branch]
    DryRun[Registry dry-runs]
    Conformance[Full conformance matrix]
    Docs[Docs version build]
    Security[SBOM + scans + checksums]
    GH[GitHub Release candidate]
    Registries[Publish registries]
    Announce[Release notes + docs]

    Dev --> RC
    RC --> DryRun
    RC --> Conformance
    RC --> Docs
    RC --> Security
    DryRun --> GH
    Conformance --> GH
    Docs --> GH
    Security --> GH
    GH --> Registries
    Registries --> Announce
```

## Required release artifacts

```text
source tarball
checksums
SBOM
native libraries
C headers
Python wheels/sdist
R package artifact
Julia artifact metadata
npm package
NuGet package
Go tag
API docs
GitHub Pages docs version
changelog
migration guide if breaking changes
```

## Pre-release policy

Use pre-release tags for binding surfaces before 1.0:

```text
0.4.0-alpha.1
0.4.0-beta.1
1.0.0-rc.1
```

## Maintenance windows

| Surface | Minimum support policy |
|---|---|
| Rust | stable Rust + stated MSRV |
| Python | 3.10-3.14 initially; remove EOL versions only in minor/major releases with notice |
| C# | .NET 10-11 target as requested; revise when runtime lifecycle requires |
| Arrow schemas | backward-compatible additive changes within same major schema version |
| FFI ABI | no breaking ABI changes without major version or side-by-side ABI |

## Release checklist

See `docs/release/release-checklist.md`.
