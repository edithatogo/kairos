# Continuous Assessment Log

Subagents should append to this file rather than losing review insights in chat.

## Current staged path

```text
v0.1: deterministic Rust scheduler + ECS + seed/replay skeleton
v0.2: Python preview + Arrow event logs + DES/ABM examples
v0.3: TypeScript/Wasm preview + playground + benchmark publication
v0.4: R/Julia/C#/Go previews + conformance suite expansion
v0.5: experiment runner + model zoo + release hardening
v1.0: stable C ABI, stable Arrow schemas, public compatibility promise
```

## Incorporated recommendations

- Community/adoption tracks.
- Research citation and archival metadata.
- OpenSSF/Scorecard/SBOM/attestations.
- V&V, uncertainty, and deterministic replay tracks.
- Experiment runner and scenario management.
- Domain starter kits and model zoo.
- Playground and browser demos.
- Cross-language API review gates.
- Standards/interoperability review.
- Red-team and devil's advocate reviews.

## Still worth considering later

| Area | Recommendation | Stage |
|---|---|---|
| Funding | OpenCollective/GitHub Sponsors after naming due diligence | after v0.2 |
| Governance | Scientific steering group or advisory board | after community traction |
| Formal methods | Kani/loom checks for scheduler invariants | after core stabilizes |
| PDES | Conservative parallel DES research spike | after sequential determinism is proven |
| Digital twins | FMI/FMU import/export spike | after experiment runner |
| RL | Gymnasium-compatible Python environment | after model zoo |
| Cloud | Batch/HPC runners and container images | after release maturity |
| Education | University course module/tutorial set | after docs site |
