# KairoECS Quality Gates

## Core Rust gates

```bash
cargo fmt --all --check
cargo clippy --workspace --all-targets --all-features -- -D warnings
cargo nextest run --workspace --all-features
cargo test --doc --workspace
cargo llvm-cov --workspace --all-features --fail-under-lines 80
cargo deny check
cargo audit
cargo semver-checks check-release
```

## Heavy/nightly gates

```bash
cargo miri test -p kairo-ecs-core
cargo miri test -p kairo-ecs-state
cargo fuzz run ffi_boundary -- -max_total_time=60
cargo bench --workspace
```

## Binding gates

| Binding | Minimum gates |
|---|---|
| Python 3.10-3.14 | `pytest`, `ruff`, type checks, wheel build, Arrow roundtrip |
| R | `R CMD check`, `testthat`, `lintr`, pkgdown build, Arrow roundtrip |
| Julia | `Pkg.test`, `Aqua.jl`, formatting, Documenter build, Arrow roundtrip |
| TypeScript | `tsc --noEmit`, `vitest`, Wasm browser/Node smoke, TypeDoc |
| C# .NET 10-11 | `dotnet test`, analyzers, NuGet pack, DocFX, Arrow roundtrip |
| Go | `go test`, `go vet`, `gofmt`, `staticcheck`, cgo smoke, Arrow roundtrip |

## Simulation-specific tests

1. Deterministic event ordering.
2. Cancellation correctness.
3. Zero-delay event guardrails.
4. Reproducible RNG streams per entity.
5. 1,000,000 entity creation and memory sanity benchmark.
6. DES resource queue fixture.
7. ABM behavior update fixture.
8. Hybrid DES/ABM fixture.
9. Arrow event log schema compatibility.
10. FFI lifecycle and double-free prevention.
11. Panic containment at FFI boundary.
12. Cross-language conformance output parity.

## Release gates

No release unless:

```text
all required CI green
all package dry-runs green
docs site green
changelog updated
compatibility notes updated
SBOM/checksums/provenance generated
security scan complete
release checklist signed off
```

## Community/SOTA gates

| Gate | Alpha | Beta | RC | 1.0 |
|---|---:|---:|---:|---:|
| CITATION.cff present | yes | yes | yes | yes |
| Model zoo examples | 3 | 6 | 8 | 10+ |
| Benchmark harness public | partial | yes | yes | yes |
| OpenSSF Scorecard workflow | scaffold | active | active | active |
| SBOM attached | optional | dry-run | yes | yes |
| Provenance/attestation | optional | dry-run | yes where supported | yes where supported |
| Red-team review | yes | yes | yes | yes |
| Compatibility promise page | yes | yes | yes | yes |
| Reproducibility docs | partial | yes | yes | yes |
