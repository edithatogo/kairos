# KairoECS Red-Team Report

## Executive summary

KairoECS is technically promising but strategically risky because it combines a new simulation kernel, ECS, DES, ABM, Arrow telemetry, FFI, six language bindings, visualization, docs, publishing, and community governance. The main risk is not that any one piece is impossible; it is that the combined scope exceeds maintainer capacity before a credible first release lands.

The review therefore recommends a staged release strategy: preserve the full SOTA architecture and Conductor track map, but publish public/stable artifacts in a narrower sequence.

## Top release-blocking risks and patch status

| Risk | Severity | Red-team critique | Countermeasure included in this pack | Status |
|---|---:|---|---|---|
| Scope explosion | Critical | Six bindings plus visualization before kernel credibility could sink the project | Track staging, release-critical path, preview/stable distinction | Patched |
| Binding generator mismatch | High | UniFFI/Diplomat may not fully cover R/Julia/Go/C# needs | Stable C ABI is canonical; generators are adapters | Patched |
| Over-promising .NET 11 | High | .NET 11 is preview, not stable production yet | `net11.0` is covered but GA-gated; .NET 10 is stable lane | Patched |
| Name collision | High | KairoECS has existing ecosystem usage | Track 00 naming due diligence and fallback names | Patched |
| Determinism claims fail under parallelism | High | PDES/parallel queues can break replay | Sequential deterministic kernel first; PDES deferred until golden traces pass | Patched |
| Arrow zero-copy overclaim | High | Arrow does not eliminate every copy/lifetime issue | Docs require exact copy semantics and schema/lifetime versioning | Patched |
| FFI unsafety | High | Use-after-free across six languages can destroy trust | Handle registry, SafeHandle/Drop/finalizer tests, fuzzing, sanitizer plan | Patched |
| Benchmark credibility | High | Benchmarks are easy to bias | Track 18 publishes harness, competitor versions, raw outputs | Patched |
| Maintainer burnout | High | Too many tracks can become permanent backlog | Subagent boundaries, release critical path, v0.1 hero path | Patched |
| Community non-adoption | High | Performance alone does not create users | Model zoo, tutorials, playground, contributor funnel | Patched |
| Security burden of native packages | High | Native artifacts increase attack surface | SBOM, attestations, OpenSSF, scorecard, dependency review | Patched |
| API fragmentation | High | Six languages can drift into six products | Track 25 API review + conformance fixtures | Patched |

## Adversarial release scenario

A realistic failure mode:

1. The project publishes a Rust crate and Python package early.
2. The Python API is convenient but leaks Rust ownership mistakes.
3. R and Julia wrappers copy too much data, weakening the Arrow claim.
4. The docs claim hybrid DES/ABM parity, but only DES examples are polished.
5. A benchmark graph appears without a reproducible harness.
6. Community trust drops before the kernel matures.

Mitigation in this pack:

```text
- preview labels on APIs
- conformance fixtures before stable bindings
- public benchmark harness before performance claims
- model zoo examples across DES, ABM, and hybrid cases
- red-team review before release candidates
```

## Recommended hard pivots

1. Make `kairo-ecs-core`, `kairo-ecs-state`, `kairo-ecs-ffi`, `kairo-ecs-arrow`, and Python the first hero path.
2. Keep R/Julia/TypeScript/C#/Go as scaffolded preview tracks until C ABI and Arrow schemas pass conformance.
3. Do not ship `kairo-ecs-viz` as part of the core release train.
4. Publish benchmark harness before publishing benchmark claims.
5. Use the model zoo as adoption strategy, not domain logic inside the kernel.
6. Add Python 3.14 free-threaded smoke tests early to catch accidental GIL assumptions.
7. Treat .NET 11 as required future coverage but not stable release promise before GA.

## Red-team release gate

No release candidate may ship unless:

- all critical risks have explicit acceptance or mitigation
- conformance fixtures pass for every package included in that release
- docs maturity labels match implemented behavior
- public performance claims link to reproducible benchmarks
- package names and legal/trademark checks are complete
- SBOM/checksums/provenance artifacts are attached for native releases
- red-team issue list has no unresolved Critical or unaccepted High risk
