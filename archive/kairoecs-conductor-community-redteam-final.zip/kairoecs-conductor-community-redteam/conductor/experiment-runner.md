# Experiment Runner and Scenario Management

The experiment runner is the bridge from “a simulation model” to “usable scientific or operational evidence.”

## `kairo-ecs-experiment` responsibilities

```text
load scenario manifests
expand parameter sweeps
allocate deterministic seeds
run replications
parallelize independent scenarios
resume failed/incomplete runs
write Arrow/Parquet outputs
write result manifests
produce comparison reports
```

## Scenario manifest sketch

```yaml
schema_version: kairoecs.scenario.v1
model: examples/des/factory_bottleneck
engine_version: 0.2.0
parameters:
  arrival_rate: 1.2
  service_rate: 1.0
replications: 100
seed_policy:
  base_seed: 12345
  stream_strategy: per_replication_per_agent
outputs:
  format: parquet
  telemetry: sampled
```

```mermaid
flowchart LR
    Manifest[Scenario manifest]
    Sweep[Parameter sweep expander]
    Seeds[Seed allocator]
    Queue[Run queue]
    Workers[Parallel workers]
    KairoECS[KairoECS engine]
    Arrow[Arrow/Parquet outputs]
    Results[Result manifest]
    Compare[Comparison report]

    Manifest --> Sweep
    Sweep --> Seeds
    Seeds --> Queue
    Queue --> Workers
    Workers --> KairoECS
    KairoECS --> Arrow
    Arrow --> Results
    Results --> Compare
```
