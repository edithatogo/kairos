# KairoECS Delivery Readiness Checklist

Use this before every alpha, beta, release candidate, and stable release.

## Product readiness

- [ ] Core DES fixture works.
- [ ] Core ABM fixture works.
- [ ] Hybrid DES/ABM fixture works.
- [ ] 1M entity/event benchmark recorded.
- [ ] Arrow telemetry works.
- [ ] FFI lifecycle works.

## Binding readiness

- [ ] Python 3.10 green.
- [ ] Python 3.11 green.
- [ ] Python 3.12 green.
- [ ] Python 3.13 green.
- [ ] Python 3.14 green.
- [ ] R package check green.
- [ ] Julia package tests green.
- [ ] TypeScript/Wasm tests green.
- [ ] C# net10.0 green.
- [ ] C# net11.0 green or explicitly marked experimental.
- [ ] Go tests green.

## Documentation readiness

- [ ] GitHub Pages site builds.
- [ ] Install page complete.
- [ ] Quickstarts for all languages.
- [ ] Factory bottleneck tutorial.
- [ ] Flocking behavior tutorial.
- [ ] Hybrid tutorial.
- [ ] FFI docs.
- [ ] Arrow schema docs.
- [ ] Release/compatibility docs.

## Governance readiness

- [ ] LICENSE.
- [ ] SECURITY.md.
- [ ] CONTRIBUTING.md.
- [ ] CODE_OF_CONDUCT.md.
- [ ] CODEOWNERS.
- [ ] Maintainers documented.
- [ ] Naming due diligence complete.

## Publishing readiness

- [ ] crates.io dry-run.
- [ ] TestPyPI/PyPI dry-run.
- [ ] npm dry-run.
- [ ] NuGet pack validation.
- [ ] R-universe or R package check.
- [ ] Julia artifact/registry dry-run.
- [ ] Go tag smoke.
- [ ] GitHub Release artifacts.
- [ ] Checksums.
- [ ] SBOM/provenance.

## Maintenance readiness

- [ ] Dependency automation active.
- [ ] Security scanning active.
- [ ] Release cadence documented.
- [ ] Deprecation policy documented.
- [ ] Compatibility policy documented.
- [ ] Issue triage labels created.

## Community and research readiness

- [ ] CITATION.cff validates.
- [ ] codemeta.json exists.
- [ ] Zenodo metadata reviewed.
- [ ] JOSS paper skeleton updated if research release.
- [ ] Model zoo includes maturity labels.
- [ ] At least one DES, one ABM, and one hybrid example run end-to-end.
- [ ] Benchmark scripts are public before benchmark claims appear in docs.
- [ ] Reproducibility command is documented for every flagship example.

## Red-team readiness

- [ ] `reviews/red-team-report.md` reviewed.
- [ ] All critical red-team findings resolved or explicitly accepted.
- [ ] Devil's advocate objections are addressed in release notes.
- [ ] Any preview/experimental claims are labelled clearly.
- [ ] .NET 11 lane is marked preview/experimental until GA.
- [ ] Arrow zero-copy claims specify exact copy/lifetime behavior.
- [ ] FFI memory safety tests passed for published bindings.
