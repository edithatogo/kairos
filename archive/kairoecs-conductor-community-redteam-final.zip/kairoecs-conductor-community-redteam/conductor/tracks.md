# KairoECS Tracks Index

This file is the Conductor-level status index. Keep it updated as `/conductor:implement` completes phases and as subagents hand off work.

| Track | Name | Status | Primary subagent | Artifact |
|---:|---|---|---|---|
| 00 | Project Foundation, Governance & Naming | Planned | `foundation-agent` | See `conductor/tracks/00-*/spec.md` |
| 01 | The Heart: kairo-ecs-core & kairo-ecs-state | Planned | `core-scheduler-agent + ecs-agent` | See `conductor/tracks/01-*/spec.md` |
| 02 | The Bridge: kairo-ecs-ffi, UniFFI & Diplomat | Planned | `ffi-agent + uniffi-agent + diplomat-agent` | See `conductor/tracks/02-*/spec.md` |
| 03 | The Flow: DES Trajectory API & ABM Behavior API | Planned | `des-api-agent + abm-api-agent` | See `conductor/tracks/03-*/spec.md` |
| 04 | The Analyst: kairo-ecs-arrow | Planned | `arrow-agent` | See `conductor/tracks/04-*/spec.md` |
| 05 | The Window: kairo-ecs-viz | Planned | `viz-agent` | See `conductor/tracks/05-*/spec.md` |
| 06 | Python Binding 3.10-3.14 | Planned | `python-agent` | See `conductor/tracks/06-*/spec.md` |
| 07 | R Binding | Planned | `r-agent` | See `conductor/tracks/07-*/spec.md` |
| 08 | Julia Binding | Planned | `julia-agent` | See `conductor/tracks/08-*/spec.md` |
| 09 | TypeScript/Wasm Binding | Planned | `typescript-agent` | See `conductor/tracks/09-*/spec.md` |
| 10 | C# Binding .NET 10-11 | Planned | `csharp-agent` | See `conductor/tracks/10-*/spec.md` |
| 11 | Go Binding | Planned | `go-agent` | See `conductor/tracks/11-*/spec.md` |
| 12 | Conformance, Testing & Benchmarks | Planned | `conformance-agent + performance-agent` | See `conductor/tracks/12-*/spec.md` |
| 13 | CI/CD, Code Quality & Supply Chain | Planned | `ci-agent + security-agent` | See `conductor/tracks/13-*/spec.md` |
| 14 | Documentation Site & Education | Planned | `docs-agent` | See `conductor/tracks/14-*/spec.md` |
| 15 | Packaging, Publishing & Delivery | Planned | `release-agent` | See `conductor/tracks/15-*/spec.md` |
| 16 | Release Governance & Maintenance | Planned | `release-agent + governance-agent` | See `conductor/tracks/16-*/spec.md` |
| 17 | Community Adoption, Education & Ecosystem | Planned | `community-agent` | See `conductor/tracks/17-*/spec.md` |
| 18 | Comparative Benchmarks & Reproducibility | Planned | `benchmark-agent` | See `conductor/tracks/18-*/spec.md` |
| 19 | Research Software, Citation & Archival | Planned | `research-agent` | See `conductor/tracks/19-*/spec.md` |
| 20 | OpenSSF, Supply Chain Trust & Institutional Readiness | Planned | `security-agent` | See `conductor/tracks/20-*/spec.md` |
| 21 | Verification, Validation & Uncertainty | Planned | `vv-uq-agent` | See `conductor/tracks/21-*/spec.md` |
| 22 | Experiment Runner & Scenario Management | Planned | `experiment-agent` | See `conductor/tracks/22-*/spec.md` |
| 23 | Domain Starter Kits & Model Zoo | Planned | `model-zoo-agent` | See `conductor/tracks/23-*/spec.md` |
| 24 | Playground, Demos & Visualization UX | Planned | `playground-agent` | See `conductor/tracks/24-*/spec.md` |
| 25 | API Design Review & Compatibility Governance | Planned | `api-governance-agent` | See `conductor/tracks/25-*/spec.md` |
| 26 | Interoperability Standards Review | Planned | `standards-agent` | See `conductor/tracks/26-*/spec.md` |
| 27 | Developer Experience & Reproducible Environments | Planned | `dx-agent` | See `conductor/tracks/27-*/spec.md` |
| 28 | Red Team & Devil's Advocate Review | Planned | `redteam-agent` | See `conductor/tracks/28-*/spec.md` |

## Track status vocabulary

```text
Planned -> Spec Approved -> In Progress -> In Review -> Blocked -> Done -> Deferred -> Cancelled
```

## Release criticality

- Tracks 00, 01, 02, 12, 13, 14, 15, 16, 20, 25, and 28 are release-gating for any public release.
- Tracks 06 and 09 are recommended v0.1/v0.2 public binding priorities.
- Tracks 07, 08, 10, and 11 can remain preview until C ABI and Arrow schema stability are proven.
- Track 05 must remain optional and non-blocking for headless releases.
