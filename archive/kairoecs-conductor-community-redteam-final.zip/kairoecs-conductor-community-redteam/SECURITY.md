# Security Policy

KairoECS includes native code and FFI surfaces. Please report suspected vulnerabilities privately.

## Supported versions

Until 1.0, only the latest release line receives security fixes unless otherwise stated.

## Reporting

Open a private security advisory on GitHub or email the security contact listed by the project maintainers once the repository is public.

Please include:

- affected version/commit
- reproduction steps
- affected language binding if relevant
- expected impact
- whether the issue is public

## Security-sensitive areas

- FFI handle ownership and lifetime
- callback boundaries
- native library loading
- package publishing workflows
- artifact signing/checksums/provenance
- deserialization of scenario manifests
- visualization/browser sandboxing
