# KairoECS Model Zoo

The model zoo is the adoption engine for KairoECS. Every model should be reproducible, documented, and tagged by maturity.

## Maturity labels

- `toy`
- `reference`
- `validated`
- `benchmark`
- `domain-preview`

## Initial model set

| Model | Paradigm | Maturity target | Languages |
|---|---|---|---|
| M/M/1 queue | DES | benchmark | Rust, Python, R, Julia |
| Factory bottleneck | DES | reference | Rust, Python |
| Flocking | ABM | reference | Rust, Python, TypeScript |
| Schelling segregation | ABM | reference | Rust, Python, Julia |
| Emergency department flow | Hybrid | domain-preview | Rust, Python, R |
| Supply chain disruption | Hybrid | reference | Rust, Python |
| Queue control Gymnasium | RL | domain-preview | Python |
