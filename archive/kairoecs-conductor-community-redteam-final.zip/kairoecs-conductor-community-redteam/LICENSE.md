# License placeholder

Recommended dual license for KairoECS:

- Apache-2.0
- MIT

Before repository publication, replace this placeholder with full `LICENSE-APACHE` and `LICENSE-MIT` files and verify compatibility for all dependencies and generated bindings.
