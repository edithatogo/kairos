# Changelog

KairoECS uses a curated changelog. Keep user-facing changes here.

## Unreleased

### Added

- Conductor setup for KairoECS tracks, subagents, release engineering, community adoption, and red-team review.
