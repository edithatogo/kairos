import importlib.util,pathlib,argparse,hashlib,json,sys
spec=importlib.util.spec_from_file_location("cap48q",pathlib.Path("docs/distributed/qualify_cap48.py").resolve());q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q)
a=argparse.Namespace(output="artifacts/cap48-external/two-host-final-anti-first",ssh_args="artifacts/cap48-external/finish-ssh-args.json",remote_repo="/content/kairos-cap48-full/kairos")
o=q.Owner(a)
try:
 o.setup();r=q.anti_before_positive(o)
 assert o.frozen_source=={n:hashlib.sha256((q.ROOT/n).read_bytes()).hexdigest() for n in o.frozen_files}
 assert o.frozen_binary==hashlib.sha256(q.BINARY.read_bytes()).hexdigest()
 receipt={"passed":1,"failed":0,"two_hosts":True,"cases":[r],"source":o.frozen_source,"local_binary_sha256":o.frozen_binary,"python":{"version":sys.version,"executable":sys.executable,"prefix":sys.prefix}}
 (o.output/"receipt.json").write_text(json.dumps(receipt,indent=2));print("CAP48_ANTI_FIRST_PASSED",flush=True)
finally:o.close()
