# C1.4 CI repair and integrated qualification contract v1

Coordinator frozen 5 October 2026 under explicit user authority to repair CI,
repeat C1.4, retain review/evidence, update completion records and parent pin.
Parent base8a8f0cb; Kairos source basec441c693eccf666d00e2720a215dd1f238e331ad.
Owners21 semantics,04 transport,12 fixtures,13 CI,15 packaging; public API review
and release/security gates remain separate. Do not touch Q5.2 concurrent paths.

## Parallel bounded work

CI inventory worker owns only .github/workflows/ci-policy.yml,
.github/workflows/workflow-security.yml and packaging/release-package-manifest.json.
Add existing careops-native-owner workflow to both inventories and the two actual
new Rust workspace package manifests to the dry-run inventory. Preserve workflow
permissions, pins, gates and production_publish_enabled=false. No scanner waiver,
action/tool/dependency upgrade, release creation or package publication.

Calibration worker owns only crates/kairo-ecs-calibration/src/{trace_mapping,
ingestion_normalize,ingestion_validate,ingestion_pipeline}.rs. Remove unused
non-test imports, use named private types/contexts for complex or overlong helper
signatures, idiomatic error/entry/iterator forms. Preserve all schemas, classification,
canonical bytes, candidate accounting, cleanup/error paths, ordering, limits and
runtime behavior. No broad allow attributes, public API additions or golden edits.

Coordinator owns crates/kairo-ecs-calibration/src/lib.rs and
crates/kairo-ecs-arrow-io/tests/interop_v1.rs. The existing contracts intentionally
keep six C1 adapters private and only their synthetic qualification exercises them.
Use production-only module-scoped expect(dead_code) with explicit pending API
review reason for this deliberate boundary (Rust1.88); do not globally suppress
warnings or make symbols public to quiet CI. Fix the redundant fixed-binary borrow.
Reviewer independently checks these decisions and final integrated diff/evidence.

## Dispatch and proof

Clean isolated worktrees, one writer per path, 3600-second advisory leases and
hashed short contracts. Read only relevant owner instructions/source. Worker
preparation checks: metadata validator and dry-run manifest check for inventories;
calibration clippy and targeted existing fixture tests for semantic refactors.
Coordinator binds exact commands/tool/cache/output paths at dispatch. Reuse the
existing target cache only serially; no concurrent Cargo processes in one target.

Before completion, review integrated source; run relevant native/schema/MSRV/
legacy and C-01 invariance gates at the fixed integrated code, repeat independent
physical/count readback and verify retained archive/member checksums. Require
hosted ci-core, package dry runs, Conductor validation and native-owner gates on
exact source head. Failed attempts remain retained. No planned check becomes pass.

Only then update parent C1.4 checkbox, C1-specific upstream owner status/handoff
and review ledger without closing unrelated phases/tracks; refresh generated
catalog/recipes, verify compatible parent pin and hosted parent gates. All claims
remain synthetic development qualification, not local-feed/clinical/release proof.
