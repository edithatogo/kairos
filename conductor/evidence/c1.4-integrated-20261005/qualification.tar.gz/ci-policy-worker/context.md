# C1.4 CI policy channel alignment

Base: `7f72b7d9a9b6ae62e481a59b2cc04ce37da0a4a5`. Frozen root contract SHA-256: `8147a8d5b9461c348c006fffdfe4fe9071afd3d71b1a9c598316e2de6742fcd1`.

Hosted run 37218289621 / job 111483217173 failed in “Rust metadata and policy files” because ci-policy searched for `channel = "stable"`; actual `rust-toolchain.toml` pins `1.99.0`. Hosted log is retained with SHA-256 `f2144b479d565a138b826f0634000b59b0aad6fcd7f6075912ded8352148ba1e`. Local pre-fix exact grep exited 1 (empty stdout/stderr retained).

Minimal correction changes only the workflow assertion to `channel = "1\.99\.0"`, matching the approved pinned toolchain. No toolchain, dependency, MSRV, permission, action or security check changes.

Verification replay: metadata/policy shell block exit 0; Track 13 metadata validator exit 0. Logs and hashes are in this packet directory.
