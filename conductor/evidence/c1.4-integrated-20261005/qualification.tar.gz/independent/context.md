# Bounded C14 independent readback v2

Expected source commit `7f72b7d9a9b6ae62e481a59b2cc04ce37da0a4a5`. The frozen contract and v1 verifier source are hashed in `packet.json`. The verifier is a copy under this owned artifact prefix; parent evidence remains unchanged. Root actual inputs are independently inventoried before read.
