# Bounded repair contract: C14 CI core interop output

Base: 7f72b7d9a9b6ae62e481a59b2cc04ce37da0a4a5.
Owned paths: `.github/workflows/ci-core.yml` and `.artifacts/c14-ci-core-env/`.
Trigger: hosted run 37218289690 failed the full-workspace `cargo llvm-cov nextest --workspace --all-features` selection because the `interop_v1` test requires `KAIROS_INTEROP_OUTDIR`; retained log SHA-256 is recorded in `packet.json`.

Change only the `Workspace tests and core coverage` step: set `KAIROS_INTEROP_OUTDIR` to a unique absolute path under `${{ github.workspace }}/.artifacts/ci/`, reject a pre-existing output directory, and create it before running the existing commands. Preserve all jobs, permissions, action/tool pins, feature/test selections, coverage threshold, uploads, MSRV gates, and dependency checks.

All-feature env inventory: `KAIROS_INTEROP_OUTDIR` is the only mandatory output variable found. `KAIROS_C11_PHYSICAL_OUTDIR` has a system-temp fallback, `KAIROS_C13_PHYSICAL_OUTDIR` has a workspace fallback, and C11 mapper/C01 capture variables are optional or gate ignored tests. No schema, dependency, native-owner, or source changes.

Checks (maximum 3): (1) `actionlint .github/workflows/ci-core.yml`; (2) `node scripts/validation/validate-track13-metadata.mjs`; (3) optional structural diff/scope check. No Cargo/cache use.
