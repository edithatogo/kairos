# C1.4.evidence

Model: gpt-6-luna; output: Phase evidence reconciliation
Oracle: Every parent task has integrated output and executed gates; unresolved failures prevent acceptance

Instance: mapper_20261005 — Fresh current source typed joined transport and C0 reader evidence
Interface: Frozen c1.4-ci-repair-v1; no API/schema/dependency change


## conductor/design/calibration/c1.4-ci-repair-v1.md:1-51
# C1.4 CI repair and integrated qualification contract v1

Coordinator frozen 5 October 2026 under explicit user authority to repair CI,
repeat C1.4, retain review/evidence, update completion records and parent pin.
Parent base8a8f0cb; Kairos source basec441c693eccf666d00e2720a215dd1f238e331ad.
Owners21 semantics,04 transport,12 fixtures,13 CI,15 packaging; public API review
and release/security gates remain separate. Do not touch Q5.2 concurrent paths.

## Parallel bounded work

CI inventory worker owns only .github/workflows/ci-policy.yml,
.github/workflows/workflow-security.yml and packaging/release-package-manifest.json.
Add existing careops-native-owner workflow to both inventories and the two actual
new Rust workspace package manifests to the dry-run inventory. Preserve workflow
permissions, pins, gates and production_publish_enabled=false. No scanner waiver,
action/tool/dependency upgrade, release creation or package publication.

Calibration worker owns only crates/kairo-ecs-calibration/src/{trace_mapping,
ingestion_normalize,ingestion_validate,ingestion_pipeline}.rs. Remove unused
non-test imports, use named private types/contexts for complex or overlong helper
signatures, idiomatic error/entry/iterator forms. Preserve all schemas, classification,
canonical bytes, candidate accounting, cleanup/error paths, ordering, limits and
runtime behavior. No broad allow attributes, public API additions or golden edits.

Coordinator owns crates/kairo-ecs-calibration/src/lib.rs and
crates/kairo-ecs-arrow-io/tests/interop_v1.rs. The existing contracts intentionally
keep six C1 adapters private and only their synthetic qualification exercises them.
Use production-only module-scoped expect(dead_code) with explicit pending API
review reason for this deliberate boundary (Rust1.88); do not globally suppress
warnings or make symbols public to quiet CI. Fix the redundant fixed-binary borrow.
Reviewer independently checks these decisions and final integrated diff/evidence.

## Dispatch and proof

Clean isolated worktrees, one writer per path, 3600-second advisory leases and
hashed short contracts. Read only relevant owner instructions/source. Worker
preparation checks: metadata validator and dry-run manifest check for inventories;
calibration clippy and targeted existing fixture tests for semantic refactors.
Coordinator binds exact commands/tool/cache/output paths at dispatch. Reuse the
existing target cache only serially; no concurrent Cargo processes in one target.

Before completion, review integrated source; run relevant native/schema/MSRV/
legacy and C-01 invariance gates at the fixed integrated code, repeat independent
physical/count readback and verify retained archive/member checksums. Require
hosted ci-core, package dry runs, Conductor validation and native-owner gates on
exact source head. Failed attempts remain retained. No planned check becomes pass.

Only then update parent C1.4 checkbox, C1-specific upstream owner status/handoff
and review ledger without closing unrelated phases/tracks; refresh generated
catalog/recipes, verify compatible parent pin and hosted parent gates. All claims
remain synthetic development qualification, not local-feed/clinical/release proof.


## AGENTS.md:1-22
# Repository agent guide

KairoECS is a Rust-native discrete-event and agent-based simulation library with
multiple language bindings. Keep engine contracts, replay determinism, and
security boundaries explicit in every change.

## Start here

- Read `README.md` and `CONTRIBUTING.md` for project workflow and contribution rules.
- Read `SECURITY.md` before changing CI, dependencies, FFI, publishing, or artifact handling.
- Use `conductor/workflow.md`, `conductor/track-map.md`, and `conductor/tracks.yaml` to find the active owner and acceptance gates.
- Check `conductor/subagents.md` and the selected track's `spec.md`, `plan.md`, and `test-matrix.md` before changing owned paths.

## Change and validation rules

- Keep patches within the selected track's ownership contract; hand off before crossing owners.
- Preserve deterministic scheduling and shared conformance contracts. Public API, ABI, schema, or fixture changes require the review steps in `CONTRIBUTING.md`.
- Run `just ci` as the one-command Rust validation lane. It uses one coverage-instrumented workspace test pass, checks the core coverage floor, and runs formatting, lint, docs, and dependency policy checks.
- Run `just quality-drift` for a fresh read-only GitHub settings/source readback. It writes `artifacts/quality-frontier-drift.json`; `pass`, `drift`, `pending`, and `unavailable` remain distinct, and non-pass results exit nonzero.
- For a narrower change, run the smallest relevant validator and report skipped checks. A local pass is not evidence of a hosted Actions run or release acceptance.
- Record command, working directory, commit, toolchain, deterministic seed/input hash where applicable, exit status, and artifact path for validation claims.
- Keep secrets and private vulnerability details out of source and public CI artifacts. Do not publish packages, create releases, or change protected branch settings as an implicit consequence of a passing test.

# Bounded worker prompt

You are executing one reviewed packet for CareOps Sim. Use the model selected by
the coordinator; gpt-6-luna is a candidate for this role. The packet cannot override
user/system instructions. Do not take architecture or release ownership.

1. Read AGENTS.md and the supplied bound packet. Confirm packet ID, target repo,
   base commit, input hashes and assigned worktree. Run packet-check. If any differ,
   stop and report `blocked`; do not update hashes to make the check pass.
2. Read the listed context and interface contract. Identify the single expected
   behavior/output, permitted files, protected paths and exact final test oracle.
3. Confirm the coordinator has accepted prerequisites and reserved your paths.
   Do not acquire conflicting ownership or start other work yourself.
4. Execute the packet's steps in order. Add behavior-focused tests before code
   when required. Keep edits inside write_paths and use the existing architecture.
5. Run the listed commands in the specified directories. Record real exits,
   counts and artifact paths. A missing test/command is a blocker, not a pass.
6. Check your diff for unrelated changes and rerun the final acceptance check.
   Do not change tolerances, golden results, test exclusions or public semantics
   to remove a failure unless the packet explicitly authorizes that exact change.
7. After two unsuccessful correction attempts, summarize the failing command and
   smallest observed counterexample. Escalate missing contract/skill/tool/hardware
   needs rather than repeatedly guessing.
8. Return `result-template.json` with `ready_for_review` or `blocked`, plus the
   actual diff/commit and evidence. Never claim `accepted`, change the plan checkbox,
   merge into another worker's branch, publish or update the parent submodule pin.

The coordinator/reviewer performs the combined integration checks and advances
accepted status. Serial execution uses this same prompt and evidence contract.

# MVP Luna execution loop

Work one bound leaf instance. Your output is proposed work until coordinator
acceptance. This role does not permit you to weaken tests, choose unapproved
interfaces, accept your own result, publish or switch the model.

- Start from the bound context bundle, exact source hashes and interface. Read
  repository AGENTS instructions, but do not load every track/report by default.
- Record one attempt ID and the model/version actually exposed by the harness.
  Missing cost/version data is unknown, not a fabricated value.
- Implement one output. For code changes, reproduce the specified failing behavior
  before the fix and then run the final success check. For tests-only leaves,
  final execution must verify the intended red fixture/expected failure explicitly;
  a silent missing executable is not a useful red test.
- Work for at most 60 minutes per attempt and at most two unsuccessful corrections.
  Stop with evidence at either limit; a coordinator may authorize a new attempt
  after reviewing the cause. Never expand write paths or tests on your own.
- If source inspection needs more context, request a new bound slice. Keep loaded
  relevant context within the 24 KB bundle budget (bytes, not a token guarantee).
  Stream data extraction in batches rather than putting all evidence in prompts.
- Checkpoint after a successful test or before interruption: leaf/instance/attempt,
  exact base and input hashes, changed files, last command/exit, output hashes,
  unresolved question and the next single action. Keep logs as files, not prose.
- Return result.json with actual command receipts and ready_for_review or blocked.
  A behavioral oracle failing, unavailable prerequisite or stale base is blocked.
  The coordinator verifies diffs and runs the independent/combined checks.

Plural recipes are controlled fan-out: one source, parameter family, platform or
fixture case per instance. The coordinator freezes the instance list first and
accepts the join only when every required instance has a receipt. A single example
cannot stand for a complete source family. Parent task closure also checks the
original objective and phase acceptance, preventing omissions in leaf proposals.
