from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

packet_path = Path(sys.argv[1]).resolve()
packet = json.loads(packet_path.read_text())
root = Path('/private/tmp/careops-c14-ci-20261005')
sys.path.insert(0, str(root / 'tools'))
import tasks
assert not tasks.packet_errors(root, packet)
child = root / packet['target_repo']
output = child / '.artifacts/c14-root'
receipts = []
for index in map(int, sys.argv[2:]):
    command = packet['verification'][index]
    label = packet['coordinator_binding']['instance_id'] + '-' + str(index)
    logfile = output / (label + '.log')
    started = time.time()
    with logfile.open('xb') as stream:
        run = subprocess.run(command['argv'], cwd=child / command['cwd'], env=dict(os.environ, **command.get('env', {})), stdout=stream, stderr=subprocess.STDOUT)
    receipt = dict(argv=command['argv'], env=command.get('env', {}), cwd=str(child / command['cwd']), head=packet['base_commit'], start=started, end=time.time(), exit_code=run.returncode, packet_sha256=hashlib.sha256(packet_path.read_bytes()).hexdigest(), input_hashes=packet['input_hashes'], log_sha256=hashlib.sha256(logfile.read_bytes()).hexdigest(), log=str(logfile), oracle=command['oracle'])
    (output / (label + '-receipt.json')).write_text(json.dumps(receipt, indent=2))
    receipts.append(receipt)
    print(label, 'exit', run.returncode, flush=True)
    if run.returncode:
        print(logfile.read_text()[-6000:], flush=True)
        raise SystemExit(run.returncode)
result = child / packet['result_path']
result.write_text(json.dumps({'status': 'executed_checks_passed_not_phase_acceptance', 'head': packet['base_commit'], 'commands': receipts}, indent=2))
