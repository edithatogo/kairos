from pathlib import Path
import json
import sys

root = Path('/private/tmp/careops-c14-ci-20261005')
sys.path.insert(0, str(root / 'tools'))
import mvp
import tasks

child = root / 'libs/kairos'
base = child / '.artifacts/c14-root'
tool = Path('/Users/doughnut/.rustup/toolchains/1.99.0-aarch64-apple-darwin/bin')
env = {'RUSTC': str(tool / 'rustc'), 'RUSTDOC': str(tool / 'rustdoc'),
       'PATH': str(tool) + ':/opt/homebrew/bin:/usr/bin:/bin',
       'CARGO_TARGET_DIR': '/private/tmp/careops-c12-lint-parent-20261004/libs/kairos/.artifacts/mvp/C1.2.deps.current_lints_20261004/target-1.99'}
checks = []
for args, oracle, extra in [
    (['clippy', '--locked', '--offline', '--workspace', '--all-targets', '--all-features', '--', '-D', 'warnings'], 'Integrated workspace warnings denied', {}),
    (['fmt', '--all', '--check'], 'Integrated formatting passes', {}),
    (['test', '--locked', '--offline', '-p', 'kairo-ecs-calibration', '--lib'], 'Calibration baseline and C01 source matrix pass; ignored transport separately executed', {'KAIROS_C01_CAPTURE_DIR': str(base / 'c01-qualification/capture')})]:
    checks.append({'argv': [str(tool / 'cargo'), *args], 'cwd': '.', 'env': dict(env, **extra), 'expected_exit': 0, 'oracle': oracle})
instance = 'native_99_20261005'
result = f'.artifacts/mvp/C1.4.evidence.{instance}/result.json'
binding = dict(reviewer='root with independent source review', reservation_id='root-c14-runtime',
               instance_id=instance, instance_scope='Native integrated CI repair qualification',
               instance_set=[instance, 'physical_20261005', 'mapper_20261005', 'readback_20261005', 'floors_20261005'],
               interface_contract='Frozen c1.4-ci-repair-v1; no API/schema/dependency change',
               context_slices=[{'repo': '.', 'path': 'conductor/design/calibration/c1.4-ci-repair-v1.md', 'start': 1, 'end': 51}, {'repo': 'libs/kairos', 'path': 'AGENTS.md', 'start': 1, 'end': 22}],
               input_paths=['Cargo.lock', *['crates/kairo-ecs-calibration/src/' + f + '.rs' for f in ['lib', 'trace_mapping', 'ingestion_normalize', 'ingestion_validate', 'ingestion_pipeline', 'ingestion_sort', 'ingestion_c01']]],
               write_paths=['.artifacts/c14-root', result], verification=checks, prerequisite_receipts={},
               reviewed_recipe_sha256='13d12d1cc86b9f9a77768ff3a5458f5fe71ac1263441142e4c3983a942983e09')
packet, context = mvp.prepare(root, tasks.derive(root), json.loads((root / mvp.RECIPES).read_text()), 'C1.4.evidence', binding)
context_path = child / packet['context_paths'][0]
context_path.parent.mkdir(parents=True, exist_ok=True)
context_path.write_text(context)
packet['input_hashes'][packet['context_paths'][0]] = mvp.digest(context_path.read_bytes())
(base / 'native-packet.json').write_text(json.dumps(packet, indent=2))
assert not tasks.packet_errors(root, packet)
(base / 'c01-qualification').mkdir(exist_ok=True)
print('Prepared and checked exact native packet')
