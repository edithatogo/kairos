import pathlib,subprocess,json,hashlib,io,tarfile,gzip,re,os
r=pathlib.Path.cwd(); head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(); members={}
def add(name,p):
 b=p.read_bytes()
 if re.search(rb'--token [a-f0-9]{32}|"token"\s*:\s*"[a-f0-9]{32}"',b): raise RuntimeError("private token in "+name)
 if name in members: raise RuntimeError("duplicate "+name)
 members[name]=b
paths=subprocess.check_output(["git","diff","--name-only","21e48b257b5c89dd9756b647d9ee17f698f9496b"],text=True).splitlines()
paths += ["conductor/research/c0.3-source-inputs-20261001/calibration-v1.schema.json","schemas/arrow/event_log_v1.schema.json","crates/kairo-ecs-arrow/src/lib.rs","crates/kairo-ecs-calibration/src/metrics.rs","crates/kairo-ecs-calibration/src/metric_cohorts.rs","crates/kairo-ecs-calibration/src/residuals.rs"]
for name in sorted(set(paths)):
 p=r/name
 if p.is_file() and not name.startswith("conductor/evidence/c4.3-arrow-20261005/"): add("source/"+name,p)
for label,root in [("root",r/".artifacts/c43-root"),("encoding",pathlib.Path("/private/tmp/kairos-c43-encoding-20261005/.artifacts/c43-encoding")),("adapter",pathlib.Path("/private/tmp/kairos-c43-adapter-20261005/.artifacts/c43-adapter")),("reader-initial",pathlib.Path("/private/tmp/kairos-c43-readback-20261005/.artifacts/c43-readback")),("reader-final",pathlib.Path("/private/tmp/kairos-c43-readback-final-20261005/.artifacts/c43-readback-final")),("framing-final",pathlib.Path("/private/tmp/kairos-c43-framing-evidence-20261005/.artifacts/c43-framing-evidence"))]:
 if not root.exists(): continue
 for p in sorted(root.rglob("*")):
  rel=p.relative_to(root)
  if p.is_file() and not p.is_symlink() and not set(rel.parts)&{"target","venv","__pycache__"} and p.name not in {"qualification.tar.gz","archive_inventory.json","archive_build_receipt.json"}: add("evidence/"+label+"/"+str(rel),p)
for name in ["encoding","adapter","readback","readback-final","framing-evidence","archive-audit"]:
 p=pathlib.Path("/private/tmp/c43-"+name+"-packet.json")
 if p.exists(): add("packets/"+p.name,p)
manifest={"source_commit":head,"members":{n:{"sha256":hashlib.sha256(b).hexdigest(),"bytes":len(b)} for n,b in sorted(members.items())},"excluded":"build caches, environments, private leases and tokens"}
members["MANIFEST.json"]=(json.dumps(manifest,indent=2,sort_keys=True)+"\n").encode()
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode="w",format=tarfile.USTAR_FORMAT) as t:
 for name,b in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname="";t.addfile(info,io.BytesIO(b))
out=r/".artifacts/c43-root/qualification.tar.gz"
with out.open("wb") as f:
 with gzip.GzipFile(filename="",mode="wb",fileobj=f,mtime=0) as g:g.write(raw.getvalue())
receipt={"source_commit":head,"archive_sha256":hashlib.sha256(out.read_bytes()).hexdigest(),"compressed_bytes":out.stat().st_size,"member_count":len(members),"uncompressed_bytes":sum(map(len,members.values())),"deterministic_metadata":True}
(r/".artifacts/c43-root/archive_inventory.json").write_text(json.dumps(manifest,indent=2,sort_keys=True)+"\n")
(r/".artifacts/c43-root/archive_build_receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt))
