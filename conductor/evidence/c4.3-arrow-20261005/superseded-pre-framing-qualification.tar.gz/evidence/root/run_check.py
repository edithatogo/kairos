import hashlib,json,os,pathlib,subprocess,sys,time
r=pathlib.Path.cwd(); name=sys.argv[1];argv=sys.argv[2:];start=time.time();prefix=r/".artifacts/c43-root"; env=os.environ.copy();env["CARGO_TARGET_DIR"]=str(prefix/"target");head=subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip();toolchain=subprocess.check_output(["rustup","run",argv[2],"rustc","-vV"],text=True) if argv[:2]==["rustup","run"] else subprocess.check_output([argv[0],"--version"],text=True,stderr=subprocess.STDOUT); log=prefix/(name+".log")
with log.open("wb") as stream: p=subprocess.run(argv,env=env,stdout=stream,stderr=subprocess.STDOUT)
tracked_dirty=subprocess.check_output(["git","status","--porcelain","--untracked-files=no"],text=True)
source_paths=subprocess.check_output(["git","ls-files"],text=True).splitlines()
source_hashes={x:hashlib.sha256((r/x).read_bytes()).hexdigest() for x in source_paths if (r/x).is_file() and (x.startswith("crates/kairo-ecs-calibration/") or x.startswith("conformance/c43/"))}
record={"tracked_dirty":tracked_dirty,"source_sha256":source_hashes,"argv":argv,"cwd":str(r),"head":head,"toolchain":toolchain,"started_unix":start,"finished_unix":time.time(),"exit_status":p.returncode,"log":str(log.relative_to(r)),"log_sha256":hashlib.sha256(log.read_bytes()).hexdigest(),"contract_sha256":hashlib.sha256((r/"conductor/design/calibration/c4.3-arrow-output-v1.md").read_bytes()).hexdigest()}
(prefix/(name+".receipt.json")).write_text(json.dumps(record,indent=2)+"\n");print(name,"exit",p.returncode);print(log.read_text()[-1800:]);sys.exit(p.returncode)
