import subprocess,sys,os
for version in ["1.99.0","1.88.0"]:
 for feature in ["", "ipc", "parquet"]:
  args=["python3",".artifacts/c43-root/run_check.py",f"final-{version}-{feature or 'none'}","rustup","run",version,"cargo","test","--locked","-p","kairo-ecs-calibration","--no-default-features"]
  if feature: args += ["--features",feature]
  args += ["--test","arrow_output_c43","--test","sidecar_adapter_c43","--test","sidecar_pipeline_c43","c43_"]
  result=subprocess.run(args)
  if result.returncode: sys.exit(result.returncode)
