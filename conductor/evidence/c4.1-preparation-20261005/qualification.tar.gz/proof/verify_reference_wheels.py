import hashlib,json,pathlib,sys,urllib.request
root=pathlib.Path(__file__).resolve().parent;records=json.loads((root/"wheel-provenance.json").read_text());proof=[]
for r in records:
    data=urllib.request.urlopen(r["metadata_url"],timeout=30).read(); metadata=json.loads(data)
    matches=[x for x in metadata["urls"] if x["filename"]==r["filename"]]; assert len(matches)==1
    x=matches[0]; local=root/"wheels"/r["filename"]; actual=hashlib.sha256(local.read_bytes()).hexdigest()
    assert actual==r["sha256"]==x["digests"]["sha256"]
    assert local.stat().st_size==r["bytes"]==x["size"]
    proof.append({"filename":r["filename"],"official_metadata_url":r["metadata_url"],"metadata_sha256":hashlib.sha256(data).hexdigest(),"wheel_sha256":actual,"bytes":local.stat().st_size,"verified_against_official_release":True})
print(json.dumps(proof,indent=2,sort_keys=True))
