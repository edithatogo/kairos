import fractions, hashlib, json, pathlib, sys
F=fractions.Fraction
root=pathlib.Path(sys.argv[1]); source=root/"conformance/c41/fixtures.json"; fx=json.loads(source.read_text())
checked=[]
for c in fx["cases"]:
    if c["expected"]["status"] != "ok": continue
    i=c["input"]; supports=[]; weights=[]
    for side in ["reference","candidate"]:
        vals=[F(v) for v in i[side] if v is not None]
        if i.get("origin") is not None: vals=[(v-F(i["origin"]))/F(i["scale_ticks"]) for v in vals]
        w=[F(w) for v,w in zip(i[side],i[side+"_weights"]) if v is not None] if side+"_weights" in i else [F(1)]*len(vals)
        total=sum(w); rows=sorted((v,wt/total) for v,wt in zip(vals,w) if wt)
        supports.append(rows); weights.append([sum(x[1] for x in rows[:k+1]) for k in range(len(rows))])
    breaks=sorted({F(0),F(1),*weights[0],*weights[1]}); w1=F(0)
    for lo,hi in zip(breaks,breaks[1:]):
        mid=(lo+hi)/2
        q=[next(v for (v,_),cumul in zip(rows,cum) if cumul>=mid) for rows,cum in zip(supports,weights)]
        w1+=(hi-lo)*abs(q[0]-q[1])
    union=sorted({v for rows in supports for v,_ in rows})
    d=max(abs(sum(w for v,w in supports[0] if v<=x)-sum(w for v,w in supports[1] if v<=x)) for x in union)
    assert w1==F(c["expected"]["w1"]),(c["id"],w1,c["expected"]["w1"])
    assert d==F(c["expected"]["ks_d"]),(c["id"],d,c["expected"]["ks_d"])
    checked.append({"id":c["id"],"w1":str(w1),"ks_d":str(d)})
out={"fixture_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),"method":"independent inverse-CDF interval integral for W1; direct normalized mass sums for descriptive D", "checked":checked,"scope":"synthetic fixture arithmetic only"}
print(json.dumps(out,sort_keys=True,indent=2))
