import os,json,subprocess,time,hashlib
from pathlib import Path
root=Path('/Volumes/PortableSSD/codex-worktrees/kairos-c44-integrated-20261005')
h='/Users/doughnut/Documents/careops-sim/tools/agent_session.py'
claim=json.loads(Path('/private/tmp/c44-native-private.json').read_text());token=claim['token']
paths=['.artifacts/c44-integrated','.artifacts/c42-report','.artifacts/c44-diagnostics-worker/target']
ha=['python3',h,'--root',str(root)]
def guard():
 subprocess.run(ha+['heartbeat','--token',token,'--ttl','3600'],check=True,stdout=subprocess.DEVNULL)
 subprocess.run(ha+['check','--token',token,'--paths',*paths],check=True,stdout=subprocess.DEVNULL)
guard()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
out=root/'.artifacts/c44-integrated'/head[:12];out.mkdir(parents=True,exist_ok=True)
tracked=subprocess.check_output(['git','ls-files','crates/kairo-ecs-calibration','conformance/c41','conformance/c43','conductor/design/calibration','Cargo.toml','Cargo.lock','rust-toolchain.toml','.github/workflows/careops-native-owner.yml','crates/kairo-ecs-arrow/src','crates/kairo-ecs-arrow-io/src'],cwd=root,text=True).splitlines()
binding={'head':head,'source_sha256':{name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in tracked},'seed_input':'Deterministic synthetic fixture; no random draws. Run seed schedule/map/contracts retained in actual source manifests.'}
(out/'source-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(out/'run-c44-native.py').write_text(Path(__file__).read_text())
python='/private/tmp/kairos-c1-ci-python-qualify-20261004/.artifacts/c1-ci-python-qualification/venv-attempt2/bin/python'
def run(label,cmd,env):
 guard();log=out/(label+'.log');start=time.time()
 with log.open('w') as f: result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 receipt={'command':cmd,'cwd':str(root),'head':head,'compiler':env.get('RUSTC'),'toolchain':env.get('C42_TOOLCHAIN'),'source_binding_sha256':hashlib.sha256((out/'source-binding.json').read_bytes()).hexdigest(),'environment':{k:env[k] for k in ('RUSTC','PATH','CARGO_TARGET_DIR','C42_REPORT_PATH','C42_PRODUCER_COMMIT','C42_TOOLCHAIN','C43_OUTPUT_DIR','C44_DIAGNOSTICS_DIR','C41_CANDIDATE_REPORT') if k in env},'exit':result.returncode,'elapsed_seconds':time.time()-start,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 (out/(label+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(label+': exit '+str(result.returncode),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
for tool,label in [('1.99.0','current'),('1.88.0','floor')]:
 compiler=subprocess.check_output(['rustup','which','--toolchain',tool,'rustc'],text=True).strip()
 env=os.environ.copy();env['RUSTC']=compiler;env['PATH']=str(Path(compiler).parent)+os.pathsep+env['PATH']
 env['CARGO_TARGET_DIR']=str(root/'.artifacts/c44-diagnostics-worker/target')
 env['C42_TOOLCHAIN']=subprocess.check_output([compiler,'--version'],text=True).strip();env['C42_PRODUCER_COMMIT']=head
 env['C42_REPORT_PATH']='.artifacts/c42-report/c44-integrated-'+head[:12]+'-'+label+'.json'
 env['C43_OUTPUT_DIR']=str(out/(label+'-output'));env['C44_DIAGNOSTICS_DIR']=str(out/(label+'-diagnostics'))
 base=['rustup','run',tool,'cargo']
 run(label+'-calibration',base+['test','--locked','--offline','-p','kairo-ecs-calibration','--all-features'],env)
 env['C41_CANDIDATE_REPORT']=str(root/env['C42_REPORT_PATH'])
 run(label+'-oracle-gate',base+['test','--locked','--offline','-p','kairo-ecs-calibration','--test','metrics_c41','c42_candidate_report','--','--ignored'],env)
 run(label+'-strict-readback',[python,'conformance/c43/readback.py','--require-manifests','--require-statistical-diagnostics','--mutation-controls',env['C43_OUTPUT_DIR']],env)
 for case in ['overlap-and-ties','empty-and-insufficient']:
  run(label+'-'+case,[python,'conformance/c43/statistical_diagnostics.py',str(Path(env['C44_DIAGNOSTICS_DIR'])/case)],env)
 if label=='current':
  run(label+'-clippy',base+['clippy','--locked','--offline','-p','kairo-ecs-calibration','--all-features','--all-targets','--','-D','warnings'],env)
run('reader-self-tests',[python,'conformance/c43/readback.py','--self-test'],os.environ.copy())
run('diff-check',['git','diff','--check'],os.environ.copy())
subprocess.run(ha+['release','--token',token],check=True,stdout=subprocess.DEVNULL)
print('All integrated gates passed; claim released.',flush=True)
