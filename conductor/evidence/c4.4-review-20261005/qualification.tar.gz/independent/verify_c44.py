#!/usr/bin/env python3
"""Independent exact C4.4 verification for integrated head 79fac7e."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
import shutil
import subprocess
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
INTEGRATED = Path("/Volumes/PortableSSD/codex-worktrees/kairos-c44-integrated-20261005")
ARTIFACTS = ROOT / ".artifacts/c44-final-independent"
RUN_DIR = INTEGRATED / ".artifacts/c44-integrated/79fac7ea52b8"
REPORT_DIR = INTEGRATED / ".artifacts/c42-report"
HEAD = "79fac7ea52b8c21650759ef2d137104fa421c48d"
SOURCE_BINDING = RUN_DIR / "source-binding.json"
TOL_W1_MULTIPLIER = 1e-12
TOL_KS = 1e-12


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path):
    return json.loads(path.read_text())


def need(condition: bool, why: str) -> None:
    if not condition:
        raise AssertionError(why)


def exact_reference_module():
    path = ROOT / "conformance/c41/generate_reference.py"
    spec = importlib.util.spec_from_file_location("c41_exact_reference", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def verify_candidate_reports() -> dict:
    ref = exact_reference_module()
    fixture_path = ROOT / "conformance/c41/fixtures.json"
    generator_path = ROOT / "conformance/c41/generate_reference.py"
    fixture = read(fixture_path)
    fixture_sha = sha(fixture_path)
    generator_sha = sha(generator_path)
    tolerance_source = ROOT / "conductor/design/calibration/c4.1-fixture-contract-v1.md"
    source_sha = hashlib.sha256(
        (ROOT / "crates/kairo-ecs-calibration/tests/metrics_c42.rs").read_bytes()
        + (ROOT / "crates/kairo-ecs-calibration/src/metrics.rs").read_bytes()
    ).hexdigest()
    summary = {}
    for toolchain in ("current", "floor"):
        path = REPORT_DIR / f"c44-integrated-79fac7ea52b8-{toolchain}.json"
        report = read(path)
        provenance = report["provenance"]
        expected_tc = "rustc 1.99.0 (b940084d7 2026-09-28)" if toolchain == "current" else "rustc 1.88.0 (6b00bc388 2025-06-23)"
        need(report["fixture_sha256"] == fixture_sha, f"{toolchain}: fixture hash mismatch")
        need(provenance["producer_commit"] == HEAD, f"{toolchain}: report head mismatch")
        need(provenance["producer_source_sha256"] == source_sha, f"{toolchain}: candidate producer source mismatch")
        need(provenance["toolchain"] == expected_tc, f"{toolchain}: report toolchain mismatch")
        actual = {c["id"]: c["result"] for c in report["cases"]}
        need(len(actual) == 42 and len(report["cases"]) == 42, f"{toolchain}: expected 42 unique cases")
        for case in fixture["cases"]:
            # The exact oracle receives the frozen input only; stored expected values are ignored.
            rebuilt = ref.make_fixture({"id": case["id"], "family": case["family"], "input": case["input"]})["expected"]
            got = actual.get(case["id"])
            need(got is not None, f"{toolchain}: missing case {case['id']}")
            scale = float(Fraction(case["input"]["scale_ticks"]))
            for key, value in rebuilt.items():
                observed = got.get(key)
                if key in ("w1", "ks_d"):
                    target = None if value is None else float(Fraction(value))
                    tol = TOL_W1_MULTIPLIER * max(1.0, scale) if key == "w1" else TOL_KS
                    need((target is None) == (observed is None), f"{toolchain}/{case['id']}/{key}: null mismatch")
                    if target is not None:
                        need(math.isfinite(observed) and abs(observed - target) <= tol,
                             f"{toolchain}/{case['id']}/{key}: oracle mismatch {observed} vs {target}")
                else:
                    need(observed == value, f"{toolchain}/{case['id']}/{key}: exact mismatch")
        summary[toolchain] = {"status": "pass", "cases": len(actual), "fixture_sha256": fixture_sha,
                              "candidate_source_sha256": source_sha, "producer_head": provenance["producer_commit"],
                              "independent_generator_sha256": generator_sha,
                              "tolerance_contract_sha256": sha(tolerance_source),
                              "toolchain": expected_tc,
                              "tolerance": {"W1": "1e-12 * max(1, scale_ticks)", "KS_D": "1e-12"}}
    return summary


def verify_receipts() -> dict:
    bind = read(SOURCE_BINDING)
    need(bind["head"] == HEAD, "source binding head mismatch")
    for rel, expected in bind["source_sha256"].items():
        blob = subprocess.check_output(["git", "show", f"{HEAD}:{rel}"], cwd=INTEGRATED)
        observed = hashlib.sha256(blob).hexdigest()
        need(observed == expected, f"committed source hash mismatch: {rel}")
    bind_sha = sha(SOURCE_BINDING)
    checks = {}
    suffixes = ["calibration", "oracle-gate", "strict-readback", "overlap-and-ties", "empty-and-insufficient"]
    for toolchain, prefix, expected_tc in (("current", "current", "rustc 1.99.0 (b940084d7 2026-09-28)"),
                                           ("floor", "floor", "rustc 1.88.0 (6b00bc388 2025-06-23)")):
        names = [f"{prefix}-{s}" for s in suffixes]
        if prefix == "current":
            names.append("current-clippy")
        for name in names:
            receipt = read(RUN_DIR / f"{name}.receipt.json")
            need(receipt.get("head") == HEAD, f"{name}: wrong executed head")
            need(receipt.get("toolchain") == expected_tc, f"{name}: wrong toolchain")
            need(receipt.get("source_binding_sha256") == bind_sha, f"{name}: source binding receipt mismatch")
            need(receipt.get("exit") == 0, f"{name}: nonzero exit")
            log = RUN_DIR / f"{name}.log"
            need(sha(log) == receipt.get("log_sha256"), f"{name}: log hash mismatch")
        checks[toolchain] = {"receipt_count": len(names), "source_binding_sha256": bind_sha,
                             "toolchain": expected_tc, "all_exit_zero": True, "logs_hash_match": True}
    reader = read(RUN_DIR / "reader-self-tests.receipt.json")
    need(reader["head"] == HEAD and reader["exit"] == 0 and reader["source_binding_sha256"] == bind_sha,
         "reader self-test receipt mismatch")
    return {"status": "pass", "source_files": len(bind["source_sha256"]), "source_binding_sha256": bind_sha,
            "toolchains": checks, "reader_self_tests": "pass"}


def verify_raw_counts() -> dict:
    directory = RUN_DIR / "current-output"
    source, join = read(directory / "source_manifest.json"), read(directory / "join_manifest.json")
    groups = join["group_summaries"]
    need(len(source["runs"]) == 1 and len(source["events"]) == 1, "unexpected source run/event counts")
    need(source["runs"][0]["seed_contract_version"] == "kairoecs.seed-purpose.v1", "seed contract not source bound")
    need(join["counts"]["residual_raw_rows"] == 15, "residual raw total mismatch")
    need(join["counts"]["residual_reference_rows"] == 8 and join["counts"]["residual_simulation_rows"] == 7,
         "residual source side counts mismatch")
    need(join["counts"]["residual_pairs"] == 8 and len(join["rows"]) == 8, "logical pair-slot count mismatch")
    summary = groups[0]
    need(summary["matched_count"] == 3 and summary["unmatched_count"] == 9, "paired/unmatched count mismatch")
    need(summary["raw_reference_count"] + summary["raw_simulation_count"] == 15, "group raw count mismatch")
    need(summary["unmatched_count"] == summary["raw_reference_count"] + summary["raw_simulation_count"] - 2 * summary["matched_count"],
         "raw-to-pair count conservation mismatch")
    need((summary["eligible_reference_count"], summary["eligible_simulation_count"]) == (5, 5), "eligible denominator mismatch")
    need((summary["excluded_count"], summary["censored_count"], summary["missing_count"],
          summary["failed_count"], summary["infeasible_count"]) == (2, 1, 1, 1, 1), "diagnostic counts mismatch")
    status_counts = dict(Counter(row["residual_status"] for row in join["rows"]))
    need(status_counts == {"computed": 4, "probe_failed": 2, "missing_observed": 1, "censored": 1},
         "residual status count mismatch")
    event_ids = {(e["run_id"], e["event_id"]) for e in source["events"]}
    refs = [(row["run_id"], raw["evidence"]["causal_ref"])
            for row in join["rows"] for raw in row["raw_records"]
            if raw.get("evidence", {}).get("causal_ref")]
    resolved = sum(pair in event_ids for pair in refs)
    return {"source_runs": 1, "source_events": 1, "residual_raw": 15, "reference_raw": 8,
            "simulation_raw": 7, "logical_pair_slots": 8, "matched_pairs": 3, "unmatched_raw_instances": 9,
            "eligible_reference": 5, "eligible_simulation": 5,
            "diagnostic_counts": {"excluded": 2, "censored": 1, "missing": 1, "failed": 1, "infeasible": 1},
            "residual_status_counts": status_counts, "causal_reference_records": len(refs),
            "causal_references_resolved": resolved}


def independent_diagnostic_check(directory: Path) -> dict:
    source = read(directory / "source_manifest.json")
    join = read(directory / "join_manifest.json")
    metrics = read(directory / "metric.json")
    window = source["source_window"]
    start, end = int(window["start_ticks"]), int(window["end_ticks"])
    defs = source["metric_groups"]
    need([d["group"] for d in defs] == sorted(d["group"] for d in defs), "declared metric groups not sorted")
    need(sum(r["side"] == "reference" for r in join["metric_raw_records"]) == source["metric_reference_rows"],
         "reference raw/source metric count mismatch")
    need(sum(r["side"] == "simulation" for r in join["metric_raw_records"]) == source["metric_simulation_rows"],
         "simulation raw/source metric count mismatch")
    checked = []
    for decl, diag in zip(defs, join["metric_group_diagnostics"]):
        group, strata = decl["group"], decl["strata"]
        need(diag["group"] == group and diag["strata"] == strata, "group declaration mismatch")
        rows = [r for r in join["metric_raw_records"] if r["group"] == group]
        selected = {side: [] for side in ("reference", "simulation")}
        totals = dict.fromkeys(("excluded", "censored", "missing", "failed", "infeasible"), 0)
        for row in rows:
            t = row["selection_time"]
            outside = t is None or not start <= int(t) < end
            totals["excluded"] += int(row["excluded"] or outside)
            totals["censored"] += int(row["censored"] or row["outcome"] == "Censored")
            totals["missing"] += int(row["missing"] or row["outcome"] == "Missing" or t is None)
            totals["failed"] += int(row["failed"] or row["outcome"] == "Failed")
            totals["infeasible"] += int(row["infeasible"] or row["outcome"] == "Infeasible")
            if not row["excluded"] and not outside and row["outcome"] == "Point":
                selected[row["side"]].append(Fraction(row["value"]))
        expected_counts = {side: len(values) for side, values in selected.items()}
        expected_ties = {side: len(values) - len(set(values)) for side, values in selected.items()}
        size = list(expected_counts.values())
        expected_status = "computed" if all(size) else "empty" if not any(size) else "insufficient_data"
        labels = {"censored": "censored_observations_present", "excluded": "excluded_observations_present",
                  "failed": "failed_outcomes_present", "infeasible": "infeasible_outcomes_present",
                  "missing": "missing_outcomes_present"}
        warnings = [labels[k] for k, value in totals.items() if value]
        if any(expected_ties.values()):
            warnings.append("tied_observations_present")
        if any(r["outcome"] == "Censored" for r in rows):
            warnings.append("uncensored_subset_no_survival_correction")
        warnings.sort()
        need(diag["status"] == expected_status, f"{group}: status mismatch")
        need((diag["reference_count"], diag["simulation_count"]) ==
             (expected_counts["reference"], expected_counts["simulation"]), f"{group}: selected counts mismatch")
        need((diag["reference_tie_count"], diag["simulation_tie_count"]) ==
             (expected_ties["reference"], expected_ties["simulation"]), f"{group}: exact Fraction tie mismatch")
        need(diag["coverage_warnings"] == warnings, f"{group}: derived warning mismatch")
        pair = [m for m in metrics if m["metric"] in ("W1", "KS_D") and m["strata"] == strata]
        need(len(pair) == 2 and {m["metric"] for m in pair} == {"W1", "KS_D"}, f"{group}: metric pair missing")
        need(pair[0]["endpoint"] == pair[1]["endpoint"] and pair[0]["window"] == pair[1]["window"] and
             pair[0]["provenance"] == pair[1]["provenance"], f"{group}: W1/KS identity mismatch")
        provenance = pair[0]["provenance"]
        run_fields = ("dataset_id", "run_id", "mapping_version", "seed_schedule_id", "seed_map_ref",
                      "parameter_hash", "seed_contract_version")
        run_matches = [r for r in source["runs"] if all(r.get(f) and provenance.get(f) == r[f] for f in run_fields)
                       and r["candidate_id"] == strata.get("candidate_id")]
        need(len(run_matches) == 1, f"{group}: no unique source run binding")
        for metric in pair:
            need(metric["status"] == diag["status"] and metric["window"] == window, f"{group}: status/window mismatch")
            need(metric["algorithm_version"] == "empirical_equal.v1" and metric["uncertainty"] is None,
                 f"{group}: algorithm or uncertainty mismatch")
            need((metric["reference_count"], metric["simulation_count"]) ==
                 (expected_counts["reference"], expected_counts["simulation"]), f"{group}: metric denominator mismatch")
            for field, key in (("excluded_count", "excluded"), ("censored_count", "censored"),
                               ("missing_count", "missing"), ("failed_count", "failed"),
                               ("infeasible_count", "infeasible")):
                need(metric[field] == totals[key], f"{group}: {field} mismatch")
            need(metric["unmatched_count"] == 0, f"{group}: unexpected unmatched count")
        checked.append({"group": group, "status": expected_status,
                        "reference_count": expected_counts["reference"], "simulation_count": expected_counts["simulation"],
                        "reference_tie_count": expected_ties["reference"], "simulation_tie_count": expected_ties["simulation"],
                        "coverage_warnings": warnings})
    return {"groups": checked, "raw_reference": source["metric_reference_rows"],
            "raw_simulation": source["metric_simulation_rows"], "status": "pass"}


def negative_controls() -> list[dict]:
    base = RUN_DIR / "current-diagnostics/overlap-and-ties"
    cases = [
        ("forged_tie_count", lambda s, j, m: j["metric_group_diagnostics"][0].__setitem__("reference_tie_count", 2)),
        ("forged_warning", lambda s, j, m: j["metric_group_diagnostics"][0].__setitem__("coverage_warnings", [])),
        ("omitted_seed_contract", lambda s, j, m: s["runs"][0].pop("seed_contract_version")),
        ("mismatched_seed_contract", lambda s, j, m: s["runs"][0].__setitem__("seed_contract_version", "other-seed")),
        ("omitted_candidate", lambda s, j, m: s["runs"][0].pop("candidate_id")),
        ("mismatched_candidate", lambda s, j, m: s["runs"][0].__setitem__("candidate_id", "other-candidate")),
    ]
    validator = INTEGRATED / "conformance/c43/statistical_diagnostics.py"
    py = "/private/tmp/kairos-c1-ci-python-qualify-20261004/.artifacts/c1-ci-python-qualification/venv-attempt2/bin/python"
    results = []
    for name, mutate in cases:
        target = ARTIFACTS / "negative-controls" / name
        target.mkdir(parents=True, exist_ok=True)
        for filename in ("join_manifest.json", "source_manifest.json", "metric.json"):
            shutil.copy2(base / filename, target / filename)
        source = read(target / "source_manifest.json")
        join = read(target / "join_manifest.json")
        metrics = read(target / "metric.json")
        mutate(source, join, metrics)
        (target / "source_manifest.json").write_text(json.dumps(source, sort_keys=True, separators=(",", ":")) + "\n")
        (target / "join_manifest.json").write_text(json.dumps(join, sort_keys=True, separators=(",", ":")) + "\n")
        (target / "metric.json").write_text(json.dumps(metrics, sort_keys=True, separators=(",", ":")) + "\n")
        run = subprocess.run([py, str(validator), str(target)], text=True, capture_output=True)
        need(run.returncode != 0, f"negative mutation unexpectedly passed: {name}")
        (target / "validator.log").write_text(
            f"exit={run.returncode}\n" + run.stdout + run.stderr
        )
        results.append({"mutation": name, "exit": run.returncode,
                        "rejection": (run.stderr + run.stdout).strip().splitlines()[-1],
                        "source_manifest_sha256": hashlib.sha256((target / "source_manifest.json").read_bytes()).hexdigest(),
                        "join_manifest_sha256": hashlib.sha256((target / "join_manifest.json").read_bytes()).hexdigest(),
                        "metric_sha256": hashlib.sha256((target / "metric.json").read_bytes()).hexdigest(),
                        "validator_log_sha256": hashlib.sha256((target / "validator.log").read_bytes()).hexdigest()})
    return results


def main():
    ref = exact_reference_module()
    uniform = ref.exact_metric([Fraction(0), Fraction(2)], [Fraction(1), Fraction(3)])
    tail = ref.exact_metric([Fraction(0)], [Fraction(0), Fraction(0), Fraction(0), Fraction(0), Fraction(900)])
    fractional = ref.exact_metric([Fraction(-1, 2), Fraction(1, 2)], [Fraction(0), Fraction(1, 3)])
    conditional = []
    fx = read(ROOT / "conformance/c41/fixtures.json")
    conditional_case = next(c for c in fx["cases"] if c["id"] == "conditional-opposite")
    grouped = conditional_case["input"]["grouped_observations"]
    for group in grouped["prespecified_groups"]:
        left = [Fraction(r[grouped["compared_variable"]]) for r in grouped["reference"]
                if r[grouped["group_variable"]] == group]
        right = [Fraction(r[grouped["compared_variable"]]) for r in grouped["candidate"]
                 if r[grouped["group_variable"]] == group]
        conditional.append(None if not left and not right else ref.exact_metric(left, right))
    need(uniform == (Fraction(1), Fraction(1, 2)), "manual uniform oracle mismatch")
    need(tail == (Fraction(180), Fraction(1, 5)), "manual tail oracle mismatch")
    need(fractional == (Fraction(1, 3), Fraction(1, 2)), "manual fractional oracle mismatch")
    need(conditional[:2] == [(Fraction(1), Fraction(1)), (Fraction(1), Fraction(1))] and conditional[2] is None,
         "manual conditional dependence oracle mismatch")
    results = {
        "schema": "c44.independent.readback.v1",
        "integrated_head": HEAD,
        "worktree_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "integrated_worktree_status_at_readback": subprocess.check_output(
            ["git", "status", "--short"], cwd=INTEGRATED, text=True).splitlines(),
        "contract_sha256": {
            "c4.4-statistical-diagnostics-v1.md": sha(ROOT / "conductor/design/calibration/c4.4-statistical-diagnostics-v1.md"),
            "c4.4-statistical-diagnostics-readback-v1.md": sha(ROOT / "conductor/design/calibration/c4.4-statistical-diagnostics-readback-v1.md"),
        },
        "candidate_reports": verify_candidate_reports(),
        "root_receipt_and_source_binding": verify_receipts(),
        "residual_count_walkthrough": verify_raw_counts(),
        "actual_diagnostics": {},
    }
    for tc in ("current", "floor"):
        for case in ("overlap-and-ties", "empty-and-insufficient"):
            path = RUN_DIR / f"{tc}-diagnostics/{case}"
            results["actual_diagnostics"][f"{tc}/{case}"] = independent_diagnostic_check(path)
    results["negative_controls"] = negative_controls()
    results["manual_analytic"] = {
        "uniform_supports_[0,2]_[1,3]": {"W1": str(uniform[0]), "KS_D": str(uniform[1])},
        "tail_[0]_[0,0,0,0,900]": {"W1": str(tail[0]), "KS_D": str(tail[1]),
                                    "reason": "CDF gap 1/5 over 900 ticks"},
        "fractional_[-1/2,1/2]_[0,1/3]": {"W1": str(fractional[0]), "KS_D": str(fractional[1]),
                                            "reason": "equal quantile distances 1/2 and 1/6"},
        "conditional_opposite_dependence": {"marginal_W1": str(Fraction(0)), "marginal_KS_D": str(Fraction(0)),
                                            "conditional_group_W1": [str(x[0]) for x in conditional[:2]],
                                            "conditional_group_KS_D": [str(x[1]) for x in conditional[:2]],
                                            "prespecified_empty_group": "empty"},
    }
    results["status"] = "pass"
    out = ARTIFACTS / "result.json"
    out.write_text(json.dumps(results, indent=2, sort_keys=True) + "\n")
    print(json.dumps(results, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
